/*
 * lacquerware -- a journalled note store speaking the Lq record protocol.
 *
 * The wire protocol is documented in PROTOCOL.md. Every frame is
 * length-prefixed and carries the four-byte domain tag "LqW1" so the parser
 * never confuses record boundaries. Records live in heap-resident slots; a
 * slot holds its own metadata so the slab can be relocated without rewriting
 * the client-facing handle table.
 */

#define _GNU_SOURCE
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

#define MAGIC     "LqW1"
#define MAX_SLOTS 32

#define OP_CREATE  0x01
#define OP_UPDATE  0x02
#define OP_COMPACT 0x03
#define OP_READ    0x04
#define OP_DELETE  0x05

#define ST_OK      0x00
#define ST_ERR     0x01

#define CREATE_MAX 0x400
#define UPDATE_MAX 0x2000
#define LABEL_MAX  32

struct note {
    uint32_t gen;
    uint32_t live;
    size_t   len;
    size_t   cap;
    char    *buf;
    char    *pending;
    size_t   plen;
    uint32_t grew;
    char     label[LABEL_MAX];
};

static struct note *slots[MAX_SLOTS];
static char *g_flag;

/* ---- framed transport over fd 0 / fd 1 ------------------------------- */

static int read_exact(void *dst, size_t n)
{
    uint8_t *p = dst;
    size_t got = 0;
    while (got < n) {
        ssize_t r = read(0, p + got, n - got);
        if (r <= 0)
            return -1;
        got += (size_t)r;
    }
    return 0;
}

static int write_all(const void *src, size_t n)
{
    const uint8_t *p = src;
    size_t sent = 0;
    while (sent < n) {
        ssize_t r = write(1, p + sent, n - sent);
        if (r <= 0)
            return -1;
        sent += (size_t)r;
    }
    return 0;
}

static int read_u32(uint32_t *out)
{
    uint8_t b[4];
    if (read_exact(b, 4) != 0)
        return -1;
    *out = ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) |
           ((uint32_t)b[2] << 8) | (uint32_t)b[3];
    return 0;
}

static int read_u64(uint64_t *out)
{
    uint8_t b[8];
    if (read_exact(b, 8) != 0)
        return -1;
    uint64_t v = 0;
    for (int i = 0; i < 8; i++)
        v = (v << 8) | b[i];
    *out = v;
    return 0;
}

static void put_u32(uint8_t *b, uint32_t v)
{
    b[0] = v >> 24; b[1] = v >> 16; b[2] = v >> 8; b[3] = v;
}

static void put_u64(uint8_t *b, uint64_t v)
{
    for (int i = 7; i >= 0; i--) { b[i] = v & 0xff; v >>= 8; }
}

static void status(uint8_t s)
{
    write_all(&s, 1);
}

/* ---- handle encoding -------------------------------------------------- */

static uint64_t make_handle(uint32_t idx, uint32_t gen)
{
    return ((uint64_t)idx << 32) | gen;
}

static struct note *resolve(uint64_t handle)
{
    uint32_t idx = handle >> 32;
    uint32_t gen = handle & 0xffffffff;
    if (idx >= MAX_SLOTS)
        return NULL;
    struct note *n = slots[idx];
    if (!n || !n->live || n->gen != gen)
        return NULL;
    return n;
}

/* ---- operations ------------------------------------------------------- */

static void op_create(void)
{
    uint32_t cap, dlen;
    uint8_t  llen;

    if (read_u32(&cap) != 0)
        return;
    if (read_exact(&llen, 1) != 0)
        return;

    char label[LABEL_MAX];
    uint8_t raw[256];
    if (read_exact(raw, llen) != 0)
        return;
    size_t copy = llen;
    if (copy > LABEL_MAX - 1)
        copy = LABEL_MAX - 1;
    size_t i;
    for (i = 0; i <= copy; i++)
        label[i] = (char)raw[i];
    label[copy] = '\0';

    if (read_u32(&dlen) != 0)
        return;
    if (cap > CREATE_MAX || dlen > CREATE_MAX) {
        status(ST_ERR);
        return;
    }
    if (cap < dlen)
        cap = dlen;

    int idx = -1;
    for (int k = 0; k < MAX_SLOTS; k++) {
        if (!slots[k]) { idx = k; break; }
    }
    if (idx < 0) {
        status(ST_ERR);
        return;
    }

    struct note *n = calloc(1, sizeof(*n));
    if (!n) { status(ST_ERR); return; }
    n->buf = malloc(cap ? cap : 1);
    if (!n->buf) { free(n); status(ST_ERR); return; }
    if (dlen && read_exact(n->buf, dlen) != 0) {
        free(n->buf); free(n); return;
    }
    n->len  = dlen;
    n->cap  = cap;
    n->gen  = 1;
    n->live = 1;
    memcpy(n->label, label, LABEL_MAX - 1);
    slots[idx] = n;

    uint8_t out[9];
    out[0] = ST_OK;
    put_u64(out + 1, make_handle((uint32_t)idx, n->gen));
    write_all(out, 9);
}

static void op_update(void)
{
    uint64_t handle;
    uint32_t dlen;

    if (read_u64(&handle) != 0)
        return;
    if (read_u32(&dlen) != 0)
        return;
    if (dlen > UPDATE_MAX) {
        status(ST_ERR);
        return;
    }

    struct note *n = resolve(handle);
    if (!n) {
        /* drain the payload so the stream stays aligned */
        uint8_t sink[256];
        uint32_t left = dlen;
        while (left) {
            uint32_t take = left > sizeof(sink) ? sizeof(sink) : left;
            if (read_exact(sink, take) != 0)
                return;
            left -= take;
        }
        status(ST_ERR);
        return;
    }

    if (dlen <= n->cap) {
        if (dlen && read_exact(n->buf, dlen) != 0)
            return;
        n->len = dlen;
        status(ST_OK);
        return;
    }

    char *staging = malloc(dlen);
    if (!staging) { status(ST_ERR); return; }
    if (read_exact(staging, dlen) != 0) {
        free(staging);
        return;
    }
    if (n->pending)
        free(n->pending);
    n->pending = staging;
    n->plen = dlen;
    n->len  = dlen;
    n->grew = 1;
    status(ST_OK);
}

static void op_compact(void)
{
    for (int k = 0; k < MAX_SLOTS; k++) {
        struct note *n = slots[k];
        if (!n || !n->live || !n->grew)
            continue;

        size_t *stitch = (size_t *)(n->buf + n->cap);
        *stitch = n->len;
        n->cap = n->len;
        memcpy(n->buf, n->pending, n->plen);
        free(n->pending);
        n->pending = NULL;
        n->plen = 0;
        n->grew = 0;
    }
    status(ST_OK);
}

static void op_read(void)
{
    uint64_t handle;
    if (read_u64(&handle) != 0)
        return;
    struct note *n = resolve(handle);
    if (!n) {
        status(ST_ERR);
        return;
    }
    uint8_t head[5];
    head[0] = ST_OK;
    put_u32(head + 1, (uint32_t)n->len);
    if (write_all(head, 5) != 0)
        return;
    write_all(n->buf, n->len);
}

static void op_delete(void)
{
    uint64_t handle;
    if (read_u64(&handle) != 0)
        return;
    uint32_t idx = handle >> 32;
    uint32_t gen = handle & 0xffffffff;
    if (idx >= MAX_SLOTS) {
        status(ST_ERR);
        return;
    }
    struct note *n = slots[idx];
    if (!n || !n->live || n->gen != gen) {
        status(ST_ERR);
        return;
    }
    free(n->buf);
    n->live = 0;
    n->gen++;
    status(ST_OK);
}

static void load_flag(void)
{
    g_flag = malloc(0x100);
    if (!g_flag)
        return;
    memset(g_flag, 0, 0x100);

    int fd = open("/srv/flag.txt", 0 /* O_RDONLY */);
    if (fd >= 0) {
        ssize_t r = read(fd, g_flag, 0xff);
        if (r < 0)
            r = 0;
        g_flag[r] = '\0';
        close(fd);
    } else {
        strcpy(g_flag, "HTL{dev_default_lacquerware}\n");
    }
}

int main(void)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);

    load_flag();

    for (;;) {
        char tag[4];
        if (read_exact(tag, 4) != 0)
            break;
        if (memcmp(tag, MAGIC, 4) != 0)
            break;

        uint8_t op;
        if (read_exact(&op, 1) != 0)
            break;

        switch (op) {
        case OP_CREATE:  op_create();  break;
        case OP_UPDATE:  op_update();  break;
        case OP_COMPACT: op_compact(); break;
        case OP_READ:    op_read();    break;
        case OP_DELETE:  op_delete();  break;
        default:
            status(ST_ERR);
            return 0;
        }
    }
    return 0;
}
