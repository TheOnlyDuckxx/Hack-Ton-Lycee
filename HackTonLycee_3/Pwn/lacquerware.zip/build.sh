#!/bin/sh
set -eu

CC=${CC:-gcc}

"$CC" \
    -O1 -g0 \
    -fPIE -pie \
    -fstack-protector-all \
    -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=0 \
    -Wl,-z,relro,-z,now \
    -Wall \
    -o store store.c

strip -s store

echo "built: store"
