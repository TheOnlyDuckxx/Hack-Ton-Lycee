# Lq record protocol (wire spec)

`lacquerware` is a journalled note store. Clients speak a binary,
length-prefixed, domain-tagged record protocol over a single TCP stream.
One connection is served by one process; the process exits when the stream
closes or a malformed frame is seen.

All integers are **big-endian**. Every frame begins with the four-byte domain
tag `LqW1` followed by a one-byte opcode. Record boundaries are always
explicit; the parser never scans for delimiters.

```
frame = "LqW1" (4 bytes) || opcode (1 byte) || body
```

## Handles

A handle is a 64-bit value `(slot_index << 32) | generation`. Handles are
returned by `CREATE` and consumed by `UPDATE` / `READ` / `DELETE`. A handle is
only valid while its slot is live and its generation matches the slot's
current generation.

## Opcodes

### 0x01 CREATE

```
body = cap:u32 || label_len:u8 || label:bytes[label_len] || data_len:u32 || data:bytes[data_len]
resp = status:u8 (0x00) || handle:u64
```

Allocates a slot. The record buffer is sized `max(cap, data_len)`. `cap` and
`data_len` are each capped at `0x400`. The label is advisory metadata.

### 0x02 UPDATE

```
body = handle:u64 || data_len:u32 || data:bytes[data_len]
resp = status:u8
```

If `data_len` fits in the record's current capacity the data is written in
place. If it is larger, the payload is staged and the record is marked for the
next compaction pass. `data_len` is capped at `0x2000`.

### 0x03 COMPACT

```
body = (none)
resp = status:u8
```

Runs a compaction pass over every live record marked by an oversize `UPDATE`,
migrating staged data into the record's buffer and adopting the new capacity.

### 0x04 READ

```
body = handle:u64
resp = status:u8 (0x00) || data_len:u32 || data:bytes[data_len]
```

Returns the record's current contents.

### 0x05 DELETE

```
body = handle:u64
resp = status:u8
```

Releases the record buffer and retires the handle generation.

## Status bytes

- `0x00` — ok
- `0x01` — error (bad handle, slot table full, size over cap)
