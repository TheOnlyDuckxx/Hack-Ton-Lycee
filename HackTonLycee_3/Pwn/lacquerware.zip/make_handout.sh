#!/bin/sh
# Assemble the player-facing handout: the exact binary, the exact libc/loader
# it was built against, and the protocol spec. Intended to be run on the build
# box after `docker build`, pulling artefacts straight out of the image so the
# shipped libc matches the deployed one byte for byte.
#
#   IMG=lacquerware sh make_handout.sh ../dist/handout
#
# Then zip the handout contents (excluding flag.txt) into dist/lacquerware.zip.
set -eu

IMG=${IMG:-lacquerware}
OUT=${1:-handout}
mkdir -p "$OUT"

cid=$(docker create "$IMG")
trap 'docker rm -f "$cid" >/dev/null 2>&1 || true' EXIT

docker cp "$cid:/srv/store" "$OUT/store"
docker cp "$cid:/lib/x86_64-linux-gnu/libc.so.6" "$OUT/libc.so.6"
docker cp "$cid:/lib64/ld-linux-x86-64.so.2" "$OUT/ld-linux-x86-64.so.2"

cp "$(dirname "$0")/PROTOCOL.md" "$OUT/PROTOCOL.md"

echo "handout assembled in $OUT:"
ls -l "$OUT"
