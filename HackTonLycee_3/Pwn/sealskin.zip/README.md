# sealskin

A tiny register virtual machine with a static safety verifier. You submit
bytecode over a TCP socket. The service **statically verifies** your program
for memory safety, then interprets it with access to a 64-slot scratch buffer.
If the verifier accepts, it prints `ACCEPT\n` and runs your program; otherwise
it prints `REJECT <reason>\n` and closes.

The interpreter trusts the verifier: `LD`/`ST` index the scratch array directly
with no runtime bounds check. The whole safety story is the verifier.

## Wire protocol

All integers are little-endian.

```
u32  prog_len         # bytes, multiple of 8, 1..8192
u8[] program          # prog_len bytes
u32  scratch_len      # bytes, 0..512
u8[] scratch_init     # scratch_len bytes, zero-padded to 512
```

## Machine model

- 8 registers `r0..r7`, each a 64-bit value. All registers start at 0.
- One scratch buffer: 64 slots of 64-bit words, index `0..63`.
- One numeric domain: unsigned 64-bit with wrap-around. Comparisons are
  unsigned except where noted.
- Control flow: **forward jumps only** (every branch/jump target must be a
  strictly later instruction). There are no loops, so the program is a DAG and
  the verifier runs a single forward pass.

## Instruction encoding

Each instruction is exactly 8 bytes:

```
offset 0: opcode  (u8)
offset 1: dst     (u8, register index)
offset 2: src     (u8, register index)
offset 3: pad     (u8, 0)
offset 4: imm     (u32, little-endian)
```

## Opcodes

| op | mnemonic      | effect                                   |
|----|---------------|------------------------------------------|
| 0  | `HALT`        | stop                                     |
| 1  | `MOV  d, imm` | `d = imm`                                |
| 2  | `MOVR d, s`   | `d = s`                                  |
| 3  | `ADD  d, s`   | `d = d + s`                              |
| 4  | `ADDI d, imm` | `d = d + imm`                            |
| 5  | `SUB  d, s`   | `d = d - s`                              |
| 6  | `SUBI d, imm` | `d = d - imm`                            |
| 7  | `AND  d, imm` | `d = d & imm`                            |
| 8  | `OR   d, imm` | `d = d | imm`                            |
| 9  | `SHL  d, imm` | `d = d << imm` (`imm < 64`)              |
| 10 | `XOR  d, s`   | `d = d ^ s`                              |
| 11 | `LD   d, s`   | `d = scratch[s]`                         |
| 12 | `ST   d, s`   | `scratch[d] = s`                         |
| 13 | `JMP  imm`    | `pc = imm`                               |
| 14 | `JLTU d,s,imm`| if `d <u s` then `pc = imm`              |
| 15 | `JEQ  d,s,imm`| if `d == s` then `pc = imm`              |
| 16 | `JSLT d,s,imm`| if `d <s s` then `pc = imm` (signed)     |
| 17 | `OUT  s`      | write 8 bytes of `s` to the socket       |
| 18 | `NOP`         | no operation                             |

## Verifier

The verifier abstractly interprets the program over a per-register domain of
`(umin, umax, off)`:

- `umin`/`umax` bound the register's value.
- `off` is the largest value the register is proven to take **when used as a
  scratch index**. It starts at "unknown" and is tightened by comparisons.

`LD d, s` and `ST d, s` require the index register's `off` to be `< 64`.
A `JLTU` against a bounding register tightens `off` on the taken edge. Where
two control-flow edges meet, the per-register state is merged.

`LD` returns an unknown value (scratch contents are attacker-controlled), so
the verifier cannot assume anything about loaded data.
