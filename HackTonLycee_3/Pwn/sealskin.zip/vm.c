/*
 * sealskin - a register bytecode runtime with a static safety verifier.
 *
 * Programs are submitted over a TCP socket, statically verified for memory
 * safety against a scratch buffer, then interpreted. The runtime trusts the
 * verifier: load/store opcodes index the scratch array directly.
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <endian.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define NREG          8
#define SCRATCH_SLOTS 64
#define MAX_INSN      1024
#define U64_MAX       0xffffffffffffffffULL

enum {
    OP_HALT = 0,
    OP_MOV,    /* dst = imm                      */
    OP_MOVR,   /* dst = src                      */
    OP_ADD,    /* dst = dst + src                */
    OP_ADDI,   /* dst = dst + imm                */
    OP_SUB,    /* dst = dst - src                */
    OP_SUBI,   /* dst = dst - imm                */
    OP_AND,    /* dst = dst & imm                */
    OP_OR,     /* dst = dst | imm                */
    OP_SHL,    /* dst = dst << imm               */
    OP_XOR,    /* dst = dst ^ src                */
    OP_LD,     /* dst = scratch[src]             */
    OP_ST,     /* scratch[dst] = src             */
    OP_JMP,    /* pc = imm                       */
    OP_JLTU,   /* if (dst <u src) pc = imm       */
    OP_JEQ,    /* if (dst == src) pc = imm       */
    OP_JSLT,   /* if (dst <s src) pc = imm       */
    OP_OUT,    /* emit 8 bytes of src            */
    OP_NOP,
    OP__COUNT
};

typedef struct {
    uint8_t  op;
    uint8_t  dst;
    uint8_t  src;
    uint8_t  pad;
    uint32_t imm;
} insn_t;

/* ---- runtime state ------------------------------------------------------ */

typedef struct VM VM;
typedef void (*handler_fn)(VM *);

struct VM {
    int64_t  regs[NREG];
    int64_t  scratch[SCRATCH_SLOTS];
    uint64_t handler_idx;
    int      conn_fd;
};

static void hdl_halt(VM *vm);
static void hdl_gift(VM *vm);

static handler_fn gates[2] = { hdl_halt, hdl_gift };

static void hdl_halt(VM *vm)
{
    const char *m = "halt\n";
    write(vm->conn_fd, m, 5);
}

static void hdl_gift(VM *vm)
{
    int fd = open("/srv/flag.txt", O_RDONLY);
    if (fd < 0) {
        const char *f = "HTL{dev_default_sealskin}\n";
        write(vm->conn_fd, f, strlen(f));
        return;
    }
    char buf[256];
    ssize_t n;
    while ((n = read(fd, buf, sizeof buf)) > 0)
        write(vm->conn_fd, buf, (size_t)n);
    close(fd);
}

/* ---- abstract domain ---------------------------------------------------- */

typedef struct {
    uint64_t umin; /* smallest possible value                     */
    uint64_t umax; /* largest possible value                      */
    uint64_t off;  /* largest value provable when used as a index */
} aval;

typedef struct {
    aval r[NREG];
    int  set;
} astate;

static aval av_const(uint64_t v)
{
    aval a;
    a.umin = v;
    a.umax = v;
    a.off  = v;
    return a;
}

static aval av_top(void)
{
    aval a;
    a.umin = 0;
    a.umax = U64_MAX;
    a.off  = U64_MAX;
    return a;
}

static aval av_add(aval a, aval b)
{
    aval r;
    uint64_t lo = a.umin + b.umin;
    uint64_t hi = a.umax + b.umax;
    if (hi < a.umax || lo < a.umin) {
        r = av_top();
        return r;
    }
    r.umin = lo;
    r.umax = hi;
    r.off  = U64_MAX;
    return r;
}

static aval av_sub(aval a, aval b)
{
    aval r;
    if (a.umin >= b.umax) {
        r.umin = a.umin - b.umax;
        r.umax = a.umax - b.umin;
        r.off  = U64_MAX;
        return r;
    }
    return av_top();
}

static aval av_and(aval a, uint64_t m)
{
    aval r;
    r.umin = 0;
    r.umax = a.umax < m ? a.umax : m;
    r.off  = r.umax;
    return r;
}

static aval av_or(aval a, uint64_t m)
{
    aval r;
    r.umin = a.umin | m;
    r.umax = U64_MAX;
    r.off  = U64_MAX;
    return r;
}

static aval av_shl(aval a, uint64_t s)
{
    aval r;
    if (s < 64 && a.umax <= (U64_MAX >> s)) {
        r.umin = a.umin << s;
        r.umax = a.umax << s;
        r.off  = U64_MAX;
        return r;
    }
    return av_top();
}

static aval av_merge(aval a, aval b)
{
    aval r;
    r.umin = a.umin < b.umin ? a.umin : b.umin;
    r.umax = a.umax > b.umax ? a.umax : b.umax;
    r.off  = a.off < b.off ? a.off : b.off;
    return r;
}

/* ---- verifier ----------------------------------------------------------- */

static astate states[MAX_INSN];

static void propagate(int target, const aval *rf)
{
    astate *s = &states[target];
    if (!s->set) {
        memcpy(s->r, rf, sizeof(aval) * NREG);
        s->set = 1;
        return;
    }
    for (int i = 0; i < NREG; i++)
        s->r[i] = av_merge(s->r[i], rf[i]);
}

static int reg_ok(const insn_t *in)
{
    return in->dst < NREG && in->src < NREG;
}

static int verify(const insn_t *prog, int n, char *err, size_t errlen)
{
    for (int i = 0; i < n; i++)
        states[i].set = 0;

    for (int i = 0; i < NREG; i++)
        states[0].r[i] = av_const(0);
    states[0].set = 1;

    for (int pc = 0; pc < n; pc++) {
        const insn_t *in = &prog[pc];

        if (in->op >= OP__COUNT) {
            snprintf(err, errlen, "bad opcode at %d", pc);
            return 0;
        }
        if (!reg_ok(in)) {
            snprintf(err, errlen, "bad register at %d", pc);
            return 0;
        }
        if (!states[pc].set)
            continue; /* unreachable */

        aval rf[NREG];
        memcpy(rf, states[pc].r, sizeof rf);

        switch (in->op) {
        case OP_HALT:
            break;

        case OP_MOV:
            rf[in->dst] = av_const(in->imm);
            propagate(pc + 1, rf);
            break;

        case OP_MOVR:
            rf[in->dst] = rf[in->src];
            propagate(pc + 1, rf);
            break;

        case OP_ADD:
            rf[in->dst] = av_add(rf[in->dst], rf[in->src]);
            propagate(pc + 1, rf);
            break;

        case OP_ADDI:
            rf[in->dst] = av_add(rf[in->dst], av_const(in->imm));
            propagate(pc + 1, rf);
            break;

        case OP_SUB:
            rf[in->dst] = av_sub(rf[in->dst], rf[in->src]);
            propagate(pc + 1, rf);
            break;

        case OP_SUBI:
            rf[in->dst] = av_sub(rf[in->dst], av_const(in->imm));
            propagate(pc + 1, rf);
            break;

        case OP_AND:
            rf[in->dst] = av_and(rf[in->dst], in->imm);
            propagate(pc + 1, rf);
            break;

        case OP_OR:
            rf[in->dst] = av_or(rf[in->dst], in->imm);
            propagate(pc + 1, rf);
            break;

        case OP_SHL:
            if (in->imm >= 64) {
                snprintf(err, errlen, "shift out of range at %d", pc);
                return 0;
            }
            rf[in->dst] = av_shl(rf[in->dst], in->imm);
            propagate(pc + 1, rf);
            break;

        case OP_XOR:
            rf[in->dst] = av_top();
            propagate(pc + 1, rf);
            break;

        case OP_LD:
            if (rf[in->src].off >= SCRATCH_SLOTS) {
                snprintf(err, errlen, "load index unbounded at %d", pc);
                return 0;
            }
            rf[in->dst] = av_top();
            propagate(pc + 1, rf);
            break;

        case OP_ST:
            if (rf[in->dst].off >= SCRATCH_SLOTS) {
                snprintf(err, errlen, "store index unbounded at %d", pc);
                return 0;
            }
            propagate(pc + 1, rf);
            break;

        case OP_JMP:
            if (in->imm <= (uint32_t)pc || in->imm >= (uint32_t)n) {
                snprintf(err, errlen, "bad jump target at %d", pc);
                return 0;
            }
            propagate((int)in->imm, rf);
            break;

        case OP_JLTU: {
            if (in->imm <= (uint32_t)pc || in->imm >= (uint32_t)n) {
                snprintf(err, errlen, "bad branch target at %d", pc);
                return 0;
            }
            aval taken[NREG], fall[NREG];
            memcpy(taken, rf, sizeof taken);
            memcpy(fall, rf, sizeof fall);
            if (rf[in->src].umax > 0) {
                uint64_t ub = rf[in->src].umax - 1;
                if (taken[in->dst].umax > ub)
                    taken[in->dst].umax = ub;
                if (taken[in->dst].off > ub)
                    taken[in->dst].off = ub;
                propagate((int)in->imm, taken);
            }
            if (fall[in->dst].umin < rf[in->src].umin)
                fall[in->dst].umin = rf[in->src].umin;
            propagate(pc + 1, fall);
            break;
        }

        case OP_JEQ: {
            if (in->imm <= (uint32_t)pc || in->imm >= (uint32_t)n) {
                snprintf(err, errlen, "bad branch target at %d", pc);
                return 0;
            }
            aval taken[NREG];
            memcpy(taken, rf, sizeof taken);
            aval d = taken[in->dst];
            aval s = rf[in->src];
            if (d.umin < s.umin) d.umin = s.umin;
            if (d.umax > s.umax) d.umax = s.umax;
            if (d.off  > s.off)  d.off  = s.off;
            taken[in->dst] = d;
            propagate((int)in->imm, taken);
            propagate(pc + 1, rf);
            break;
        }

        case OP_JSLT:
            if (in->imm <= (uint32_t)pc || in->imm >= (uint32_t)n) {
                snprintf(err, errlen, "bad branch target at %d", pc);
                return 0;
            }
            propagate((int)in->imm, rf);
            propagate(pc + 1, rf);
            break;

        case OP_OUT:
            propagate(pc + 1, rf);
            break;

        case OP_NOP:
            propagate(pc + 1, rf);
            break;

        default:
            snprintf(err, errlen, "bad opcode at %d", pc);
            return 0;
        }
    }
    return 1;
}

/* ---- interpreter -------------------------------------------------------- */

static void run(VM *vm, const insn_t *prog, int n)
{
    int pc = 0;
    long steps = 0;

    while (pc >= 0 && pc < n) {
        if (++steps > 1000000)
            return;
        const insn_t *in = &prog[pc];
        int64_t *R = vm->regs;

        switch (in->op) {
        case OP_HALT:
            gates[vm->handler_idx](vm);
            return;
        case OP_MOV:
            R[in->dst] = (int64_t)(uint64_t)in->imm;
            pc++;
            break;
        case OP_MOVR:
            R[in->dst] = R[in->src];
            pc++;
            break;
        case OP_ADD:
            R[in->dst] = R[in->dst] + R[in->src];
            pc++;
            break;
        case OP_ADDI:
            R[in->dst] = R[in->dst] + (int64_t)(uint64_t)in->imm;
            pc++;
            break;
        case OP_SUB:
            R[in->dst] = R[in->dst] - R[in->src];
            pc++;
            break;
        case OP_SUBI:
            R[in->dst] = R[in->dst] - (int64_t)(uint64_t)in->imm;
            pc++;
            break;
        case OP_AND:
            R[in->dst] = (int64_t)((uint64_t)R[in->dst] & (uint64_t)in->imm);
            pc++;
            break;
        case OP_OR:
            R[in->dst] = (int64_t)((uint64_t)R[in->dst] | (uint64_t)in->imm);
            pc++;
            break;
        case OP_SHL:
            R[in->dst] = (int64_t)((uint64_t)R[in->dst] << (in->imm & 63));
            pc++;
            break;
        case OP_XOR:
            R[in->dst] = R[in->dst] ^ R[in->src];
            pc++;
            break;
        case OP_LD: {
            uint64_t idx = (uint64_t)R[in->src];
            R[in->dst] = vm->scratch[idx];
            pc++;
            break;
        }
        case OP_ST: {
            uint64_t idx = (uint64_t)R[in->dst];
            vm->scratch[idx] = R[in->src];
            pc++;
            break;
        }
        case OP_JMP:
            pc = (int)in->imm;
            break;
        case OP_JLTU:
            if ((uint64_t)R[in->dst] < (uint64_t)R[in->src])
                pc = (int)in->imm;
            else
                pc++;
            break;
        case OP_JEQ:
            if (R[in->dst] == R[in->src])
                pc = (int)in->imm;
            else
                pc++;
            break;
        case OP_JSLT:
            if (R[in->dst] < R[in->src])
                pc = (int)in->imm;
            else
                pc++;
            break;
        case OP_OUT: {
            uint64_t v = (uint64_t)R[in->src];
            write(vm->conn_fd, &v, sizeof v);
            pc++;
            break;
        }
        case OP_NOP:
            pc++;
            break;
        default:
            return;
        }
    }
}

/* ---- wire protocol ------------------------------------------------------ */

static int read_full(int fd, void *buf, size_t len)
{
    uint8_t *p = buf;
    size_t got = 0;
    while (got < len) {
        ssize_t n = read(fd, p + got, len - got);
        if (n <= 0)
            return 0;
        got += (size_t)n;
    }
    return 1;
}

static void reject(int fd, const char *msg)
{
    char line[160];
    int k = snprintf(line, sizeof line, "REJECT %s\n", msg);
    write(fd, line, (size_t)k);
}

static void handle(int fd)
{
    uint32_t prog_len = 0, scr_len = 0;
    if (!read_full(fd, &prog_len, 4)) return;
    prog_len = le32toh(prog_len);
    if (prog_len == 0 || prog_len % 8 != 0 || prog_len > MAX_INSN * 8) {
        reject(fd, "bad program length");
        return;
    }

    int n = (int)(prog_len / 8);
    static uint8_t raw[MAX_INSN * 8];
    if (!read_full(fd, raw, prog_len)) return;

    static insn_t prog[MAX_INSN];
    for (int i = 0; i < n; i++) {
        uint8_t *b = raw + i * 8;
        prog[i].op  = b[0];
        prog[i].dst = b[1];
        prog[i].src = b[2];
        prog[i].pad = b[3];
        prog[i].imm = (uint32_t)b[4] | ((uint32_t)b[5] << 8) |
                      ((uint32_t)b[6] << 16) | ((uint32_t)b[7] << 24);
    }

    if (!read_full(fd, &scr_len, 4)) return;
    scr_len = le32toh(scr_len);
    if (scr_len > SCRATCH_SLOTS * 8) {
        reject(fd, "scratch too large");
        return;
    }

    VM *vm = calloc(1, sizeof(VM));
    if (!vm) return;
    vm->conn_fd = fd;
    vm->handler_idx = 0;

    if (scr_len > 0) {
        if (!read_full(fd, (uint8_t *)vm->scratch, scr_len)) {
            free(vm);
            return;
        }
    }

    char err[128];
    if (!verify(prog, n, err, sizeof err)) {
        reject(fd, err);
        free(vm);
        return;
    }

    write(fd, "ACCEPT\n", 7);
    run(vm, prog, n);
    free(vm);
}

int main(int argc, char **argv)
{
    int port = argc > 1 ? atoi(argv[1]) : 9103;

    signal(SIGCHLD, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);

    int srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0) { perror("socket"); return 1; }

    int one = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);

    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) < 0) {
        perror("bind");
        return 1;
    }
    if (listen(srv, 16) < 0) {
        perror("listen");
        return 1;
    }

    for (;;) {
        int fd = accept(srv, NULL, NULL);
        if (fd < 0)
            continue;
        pid_t pid = fork();
        if (pid == 0) {
            close(srv);
            alarm(20);
            handle(fd);
            shutdown(fd, SHUT_RDWR);
            close(fd);
            _exit(0);
        }
        close(fd);
    }
    return 0;
}
