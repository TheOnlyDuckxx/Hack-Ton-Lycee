# Harcourt DR-7 "Dead Reckoning" sensor gateway

A bare-metal ARM Cortex-M3 firmware for a fictional marine sensor gateway. It
runs under QEMU (`mps2-an385`) and speaks a small framed TLV protocol over its
UART0, which the platform bridges to a TCP socket. Connect and send frames; the
device answers over the same socket.

## Device model

- **Core**: ARMv7-M, Cortex-M3, no ASLR, MPU enabled (RAM is execute-never),
  the XN permission enforced on the default map.
- **No libc / no RTOS vendor blob**: a cooperative task core, a hand-rolled
  first-fit heap with inline boundary tags, and a return-address shadow stack.
- **Shadow stack**: instrumented routines push their return address to a
  separate region on entry and re-validate it on exit. A mismatch (a smashed
  saved return address) resets the device immediately.
- **Secure flash**: a reserved flash page holds a maintenance secret. No
  network command reads it; only the firmware's internal `flash_read` routine
  touches that page, and it is not wired to any command.

## Memory map

| Region            | Base          | Notes                              |
|-------------------|---------------|------------------------------------|
| Vectors + `.text` | `0x00000000`  | code / rodata                      |
| Service routines  | `0x00008000`  | fixed-address maintenance pages    |
| Secure flash      | `0x0000C000`  | maintenance secret                 |
| `.data` / `.bss`  | `0x20000000`  | RW data                            |
| Shadow stack      | `0x20008000`  | return-address mirror              |
| Heap              | `0x20010000`  | first-fit, inline boundary tags    |
| Main stack top    | `0x20040000`  | grows down                         |

## Heap chunks

Every allocation is prefixed by an 8-byte inline header:

```
offset 0: u32 size     # total bytes incl header, 8-aligned; bit0 = in-use
offset 4: u32 prevsz   # total size of the physically previous chunk
```

The allocator walks the heap on every `alloc`, validating that each chunk's
`prevsz` equals the previous chunk's `size` (the boundary-tag / coalescing
invariant). A violation is treated as corruption and resets the device.

## Wire protocol

Every message is an 8-byte frame header followed by a body. All integers are
little-endian.

```
offset 0: u8  magic0 = 'D'
offset 1: u8  magic1 = 'R'
offset 2: u8  version = 1
offset 3: u8  cmd
offset 4: u16 seg_len     # "segment length" carried in the framing header
offset 6: u16 body_len    # number of body bytes that follow (<= 2048)
```

After reading `body_len` body bytes, the device checks `seg_len <= body_len`
and dispatches on `cmd`:

| cmd | name     | body                                    |
|-----|----------|-----------------------------------------|
| 1   | `STORE`  | one TLV record (see below)              |
| 2   | `OPEN`   | empty — creates a sensor task           |
| 3   | `REPORT` | empty — the active task reports status  |
| 4   | `ECHO`   | one TLV record — echoes the first bytes |

### TLV record (body of `STORE` / `ECHO`)

```
offset 0: u8  type
offset 1: u16 tlv_len     # length of the record value
offset 3: u8[tlv_len] value
```

`tlv_len` is validated against the remaining body. `STORE` keeps a single
session buffer: the first `STORE` allocates it sized to `tlv_len`; later
`STORE`s reuse it. `OPEN` creates a sensor task whose status handler is called
indirectly on `REPORT`.

## Responses

The device replies with short ASCII status lines (`OK store`, `OK open`,
`STAT ...`, or `ERR ...`) terminated by `\n`.
