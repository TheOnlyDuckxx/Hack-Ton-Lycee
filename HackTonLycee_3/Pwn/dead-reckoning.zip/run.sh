#!/bin/sh
set -eu

exec qemu-system-arm \
    -M mps2-an385 \
    -cpu cortex-m3 \
    -display none \
    -monitor none \
    -semihosting-config enable=off \
    -kernel /srv/firmware.elf \
    -serial tcp::9104,server=on,wait=off
