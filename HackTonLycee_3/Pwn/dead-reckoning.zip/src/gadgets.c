/*
 * Low-level service routines for the Harcourt DR-7 gateway firmware.
 *
 * These live in their own fixed-address flash pages so the bootstrap ROM can
 * patch them in the field without relinking the main image. They are written
 * in assembly because they run before the C runtime stack is known-good.
 */

__attribute__((naked, used, section(".g_pivot")))
void svc_restore_ctx(void)
{
    __asm__ volatile(
        "ldr r1, [r0, #12]\n"
        "mov sp, r1\n"
        "pop {r0, pc}\n");
}

__attribute__((naked, used, section(".g_setr1")))
void svc_set_len(void)
{
    __asm__ volatile(
        "pop {r1, pc}\n");
}

__attribute__((naked, used, section(".g_flash")))
void flash_read(void)
{
    __asm__ volatile(
        "movw r3, #0x4000\n"
        "movt r3, #0x4000\n"
        "1:\n"
        "cmp r1, #0\n"
        "beq 3f\n"
        "ldrb r2, [r0]\n"
        "cmp r2, #0\n"
        "beq 3f\n"
        "2:\n"
        "ldr r12, [r3, #4]\n"
        "tst r12, #1\n"
        "bne 2b\n"
        "str r2, [r3, #0]\n"
        "adds r0, r0, #1\n"
        "subs r1, r1, #1\n"
        "b 1b\n"
        "3:\n"
        "movw r3, #0x80c1\n"
        "movt r3, #0x0000\n"
        "bx r3\n");
}

__attribute__((naked, used, section(".g_finish")))
void svc_reboot(void)
{
    __asm__ volatile(
        "movw r3, #0xed0c\n"
        "movt r3, #0xe000\n"
        "movw r2, #0x0004\n"
        "movt r2, #0x05fa\n"
        "dsb\n"
        "str r2, [r3]\n"
        "dsb\n"
        "1: b 1b\n");
}
