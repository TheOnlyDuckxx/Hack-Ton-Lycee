/* Generated at image build from chal/flag.txt. The value below is the
 * development fallback and is what ships in the player source distribution. */
__attribute__((section(".secret"), used))
const char secret_region[128] = "HTL{dev_default_deadreckoning}";
