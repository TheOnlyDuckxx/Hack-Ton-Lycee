/*
 * Harcourt DR-7 "Dead Reckoning" sensor gateway firmware.
 *
 * Bare-metal ARMv7-M (Cortex-M3). No libc, no RTOS vendor blob: a tiny
 * cooperative task core, a first-fit heap with inline boundary tags, a
 * return-address shadow stack, and a framed TLV command protocol spoken over
 * UART0. See README.md for the datasheet and wire format.
 */

#include <stdint.h>
#include <stddef.h>

/* ------------------------------------------------------------------ */
/* CMSDK APB UART0 (MPS2-AN385)                                        */
/* ------------------------------------------------------------------ */
#define UART0_BASE   0x40004000u
#define UART_DATA    (*(volatile uint32_t *)(UART0_BASE + 0x00))
#define UART_STATE   (*(volatile uint32_t *)(UART0_BASE + 0x04))
#define UART_CTRL    (*(volatile uint32_t *)(UART0_BASE + 0x08))
#define UART_BAUD    (*(volatile uint32_t *)(UART0_BASE + 0x10))
#define UART_TX_FULL 0x1u
#define UART_RX_RDY  0x2u

/* ------------------------------------------------------------------ */
/* System control (reset, MPU)                                         */
/* ------------------------------------------------------------------ */
#define SCB_AIRCR    (*(volatile uint32_t *)0xE000ED0Cu)
#define MPU_CTRL     (*(volatile uint32_t *)0xE000ED94u)
#define MPU_RNR      (*(volatile uint32_t *)0xE000ED98u)
#define MPU_RBAR     (*(volatile uint32_t *)0xE000ED9Cu)
#define MPU_RASR     (*(volatile uint32_t *)0xE000EDA0u)

extern uint32_t _sidata, _sdata, _edata, _sbss, _ebss, _estack;

void reset_handler(void);

static void device_reset(void)
{
    __asm__ volatile("dsb");
    SCB_AIRCR = 0x05FA0004u;
    __asm__ volatile("dsb");
    for (;;) { }
}

__attribute__((used)) void fault_handler(void)
{
    device_reset();
}

__attribute__((section(".vectors"), used))
void (*const g_vectors[])(void) = {
    (void (*)(void))(&_estack),      /* 0  initial SP            */
    reset_handler,                   /* 1  reset                 */
    fault_handler,                   /* 2  NMI                   */
    fault_handler,                   /* 3  HardFault             */
    fault_handler,                   /* 4  MemManage             */
    fault_handler,                   /* 5  BusFault              */
    fault_handler,                   /* 6  UsageFault            */
    0, 0, 0, 0,                      /* 7-10 reserved            */
    fault_handler,                   /* 11 SVCall                */
    0, 0,                            /* 12-13 reserved           */
    fault_handler,                   /* 14 PendSV                */
    fault_handler,                   /* 15 SysTick               */
    /* external IRQs: unused (polled UART) */
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
};

/* ------------------------------------------------------------------ */
/* UART                                                                */
/* ------------------------------------------------------------------ */
static void uart_init(void)
{
    UART_BAUD = 16;
    UART_CTRL = 0x3;  /* TX + RX enable */
}

static void uart_putc(uint8_t c)
{
    while (UART_STATE & UART_TX_FULL) { }
    UART_DATA = c;
}

static void uart_write(const void *p, uint32_t n)
{
    const uint8_t *b = p;
    for (uint32_t i = 0; i < n; i++)
        uart_putc(b[i]);
}

static void uart_puts(const char *s)
{
    while (*s)
        uart_putc((uint8_t)*s++);
}

static uint8_t uart_getc(void)
{
    while (!(UART_STATE & UART_RX_RDY)) { }
    return (uint8_t)(UART_DATA & 0xFF);
}

static void uart_read_exact(void *p, uint32_t n)
{
    uint8_t *b = p;
    for (uint32_t i = 0; i < n; i++)
        b[i] = uart_getc();
}

/* ------------------------------------------------------------------ */
/* small freestanding helpers                                          */
/* ------------------------------------------------------------------ */
static void bcopy_fwd(void *dst, const void *src, uint32_t n)
{
    uint8_t *d = dst;
    const uint8_t *s = src;
    while (n--)
        *d++ = *s++;
}

static void bzero_mem(void *dst, uint32_t n)
{
    uint8_t *d = dst;
    while (n--)
        *d++ = 0;
}

/* ------------------------------------------------------------------ */
/* MPU: mark RAM execute-never, keep the privileged default map        */
/* ------------------------------------------------------------------ */
static void mpu_init(void)
{
    MPU_RNR  = 0;
    MPU_RBAR = 0x20000000u;
    /* XN=1, AP=full RW, size=512MB, enable */
    MPU_RASR = (1u << 28) | (0x3u << 24) | (28u << 1) | 1u;
    MPU_CTRL = 0x5u;  /* ENABLE | PRIVDEFENA */
    __asm__ volatile("dsb; isb");
}

/* ------------------------------------------------------------------ */
/* return-address shadow stack                                         */
/* ------------------------------------------------------------------ */
__attribute__((section(".shadow"), used)) static uint32_t g_shadow[256];
static uint32_t g_shadow_sp;

#define GUARD_ENTER()                                                  \
    do {                                                               \
        g_shadow[g_shadow_sp++ & 0xFF] =                               \
            (uint32_t)__builtin_return_address(0);                     \
    } while (0)

#define GUARD_LEAVE()                                                  \
    do {                                                               \
        uint32_t __saved = g_shadow[--g_shadow_sp & 0xFF];             \
        if (__saved != (uint32_t)__builtin_return_address(0))          \
            device_reset();                                            \
    } while (0)

/* ------------------------------------------------------------------ */
/* first-fit heap with inline boundary tags                            */
/* ------------------------------------------------------------------ */
#define HEAP_SIZE 0x8000u

typedef struct {
    uint32_t size;    /* total bytes incl header, 8-aligned; bit0 = in-use */
    uint32_t prevsz;  /* total size of the physically previous chunk       */
} chunk_t;

__attribute__((section(".heap"), used)) static uint8_t g_heap[HEAP_SIZE];
static uint32_t g_brk;
static uint32_t g_prev_total;

static uint32_t align8(uint32_t n)
{
    return (n + 7u) & ~7u;
}

static void heap_scan(void)
{
    uint32_t off = 0;
    uint32_t prev = 0;
    while (off < g_brk) {
        chunk_t *c = (chunk_t *)(g_heap + off);
        uint32_t sz = c->size & ~0x7u;
        if (sz == 0 || (sz & 7u) || off + sz > HEAP_SIZE)
            device_reset();
        if (c->prevsz != prev)
            device_reset();
        prev = sz;
        off += sz;
    }
}

static void *halloc(uint32_t n)
{
    uint32_t total = align8(n + sizeof(chunk_t));
    heap_scan();
    if (g_brk + total > HEAP_SIZE)
        return NULL;
    chunk_t *c = (chunk_t *)(g_heap + g_brk);
    c->size = total | 1u;
    c->prevsz = g_prev_total;
    g_prev_total = total;
    void *payload = g_heap + g_brk + sizeof(chunk_t);
    g_brk += total;
    return payload;
}

/* ------------------------------------------------------------------ */
/* cooperative task core                                               */
/* ------------------------------------------------------------------ */
struct tcb;
typedef struct {
    void (*init)(struct tcb *);
    void (*poll)(struct tcb *);
    void (*report)(struct tcb *);
} task_ops;

typedef struct tcb {
    uint32_t id;
    uint32_t flags;
    const task_ops *ops;
    uint32_t piv;
    uint32_t pad[12];
} tcb;

static void sensor_init(tcb *t)   { t->flags |= 1u; }
static void sensor_poll(tcb *t)   { t->flags += 1u; }
static void sensor_report(tcb *t)
{
    uart_puts("STAT id=");
    uart_putc('0' + (uint8_t)(t->id & 7));
    uart_puts(" ok\n");
}

static const task_ops g_sensor_ops = {
    sensor_init, sensor_poll, sensor_report
};

static tcb *g_task;
static uint8_t *g_sess;

/* ------------------------------------------------------------------ */
/* framed TLV protocol                                                 */
/* ------------------------------------------------------------------ */
#define CMD_STORE   1
#define CMD_OPEN    2
#define CMD_REPORT  3
#define CMD_ECHO    4

#define BODY_MAX    2048u

static uint8_t g_body[BODY_MAX];

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)(p[0] | (p[1] << 8));
}

static void cmd_store(uint16_t seg_len, uint16_t body_len)
{
    if (body_len < 3)
        return;
    uint16_t tlv_len = rd16(&g_body[1]);
    if (tlv_len > body_len - 3) {
        uart_puts("ERR tlv\n");
        return;
    }
    const uint8_t *value = &g_body[3];

    if (g_sess == NULL)
        g_sess = halloc(tlv_len);
    if (g_sess == NULL) {
        uart_puts("ERR mem\n");
        return;
    }
    bcopy_fwd(g_sess, value, seg_len);
    uart_puts("OK store\n");
}

static void cmd_open(void)
{
    g_task = halloc(sizeof(tcb));
    if (g_task == NULL) {
        uart_puts("ERR mem\n");
        return;
    }
    bzero_mem(g_task, sizeof(tcb));
    g_task->id = 1;
    g_task->ops = &g_sensor_ops;
    g_task->ops->init(g_task);
    uart_puts("OK open\n");
}

static void cmd_report(void)
{
    if (g_task == NULL) {
        uart_puts("ERR notask\n");
        return;
    }
    uint8_t *resp = halloc(32);
    if (resp == NULL) {
        uart_puts("ERR mem\n");
        return;
    }
    bzero_mem(resp, 32);
    g_task->ops->report(g_task);
}

static void cmd_echo(uint16_t seg_len, uint16_t body_len)
{
    GUARD_ENTER();
    uint8_t scratch[64];
    if (body_len >= 3) {
        const uint8_t *value = &g_body[3];
        bcopy_fwd(scratch, value, seg_len);
        uart_write(scratch, 16);
        uart_putc('\n');
    }
    GUARD_LEAVE();
}

static void serve(void)
{
    for (;;) {
        uint8_t hdr[8];
        uart_read_exact(hdr, 8);
        if (hdr[0] != 'D' || hdr[1] != 'R' || hdr[2] != 1) {
            uart_puts("ERR frame\n");
            return;
        }
        uint8_t cmd = hdr[3];
        uint16_t seg_len = rd16(&hdr[4]);
        uint16_t body_len = rd16(&hdr[6]);

        if (body_len > BODY_MAX) {
            uart_puts("ERR big\n");
            return;
        }
        uart_read_exact(g_body, body_len);

        if (seg_len > body_len) {
            uart_puts("ERR seg\n");
            return;
        }

        switch (cmd) {
        case CMD_STORE:  cmd_store(seg_len, body_len);  break;
        case CMD_OPEN:   cmd_open();                    break;
        case CMD_REPORT: cmd_report();                  break;
        case CMD_ECHO:   cmd_echo(seg_len, body_len);   break;
        default:         uart_puts("ERR cmd\n");        break;
        }
    }
}

void reset_handler(void)
{
    uint32_t *src = &_sidata;
    uint32_t *dst = &_sdata;
    while (dst < &_edata)
        *dst++ = *src++;
    for (dst = &_sbss; dst < &_ebss; )
        *dst++ = 0;

    g_brk = 0;
    g_prev_total = 0;
    g_shadow_sp = 0;
    g_task = NULL;
    g_sess = NULL;

    uart_init();
    mpu_init();

    uart_puts("DR-7 gateway online\n");
    serve();

    device_reset();
    for (;;) { }
}
