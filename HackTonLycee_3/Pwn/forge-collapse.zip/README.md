# forge

A tiny JavaScript-subset engine with a baseline optimizing JIT. You connect
over TCP, send one source program, and the engine parses it to bytecode, runs
it, and streams anything the program emits back to you. Functions that execute
often enough are handed to a small method JIT.

## Wire protocol

All integers are little-endian.

```
u32  src_len          # bytes, 1 .. 1<<20
u8[] source           # UTF-8 program text
```

The connection has a short wall-clock budget. The program's output (and the
engine's one trailing newline) is written back on the same socket.

## Language

A deliberately small subset of JavaScript:

- Numbers are IEEE-754 doubles. There is no string, boolean, or object-literal
  type; the only heap aggregate is the array.
- `var name = expr;` declares a function-local (there is no block scope and no
  closures). Top-level `var`s are locals of an implicit `main`.
- Arithmetic `+ - * / %`, comparisons `< > == !=`.
- Array literals `[a, b, c]` and element access `arr[i]` for get and set.
- `function name(params) { ... }` with `return`. Functions are values; naming
  one without calling it yields the function object. No nested functions.
- `while (cond) { ... }` and `if (cond) { ... } else { ... }`.
- Line comments `// ...`.

### Builtins

| builtin         | effect                                                        |
|-----------------|---------------------------------------------------------------|
| `u64(hi, lo)`   | the number whose raw 64-bit payload is `(hi<<32)|lo`          |
| `hi(x)`         | high 32 bits of `x`'s raw payload, as a number                |
| `lo(x)`         | low 32 bits of `x`'s raw payload, as a number                 |
| `floor(x)`      | floor of `x`                                                  |
| `send(x)`       | write the 8 raw payload bytes of `x` to the socket            |

## Value representation

Values are NaN-boxed into a 64-bit word:

```
double   v  ==  rawbits(v) + (1 << 48)
heap ptr p  ==  p                        (the object arena lives below 1<<48)
```

Arrays specialize their backing store by elements kind. A DOUBLE array stores
unboxed raw doubles; an OBJECT array stores boxed cell values. Storing a value
whose representation does not match the current kind transitions the array to
the other kind and rewrites the slot.

## Execution tiers

The program runs on a stack-bytecode interpreter. A function that is called
past a fixed threshold and whose body fits the JIT's supported straight-line
opcode subset is lowered to native x86-64: the IR is built, a couple of
redundancy-elimination passes run, and code is emitted into an executable page
that the function then calls directly.

## Build

```
sh build.sh      # produces ./engine
./engine 9101    # serve on port 9101
```
