#!/bin/sh
set -e

gcc -O2 -Wall -Wextra -std=c11 \
    -fstack-protector-strong -fPIE -pie \
    -Wl,-z,relro,-z,now -Wl,-z,noexecstack \
    -o engine engine.c

strip engine
