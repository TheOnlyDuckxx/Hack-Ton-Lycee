/*
 * forge - a tiny JavaScript-subset engine with a baseline optimizing JIT.
 *
 * Programs arrive over a TCP socket as UTF-8 source, are parsed to a compact
 * stack bytecode, and interpreted. Functions that run hot are handed to a
 * small method JIT that lowers a straight-line region to native x86-64 and
 * runs a couple of redundancy-elimination passes over the IR first.
 *
 * Value representation is NaN-boxed into a 64-bit word:
 *
 *     double   v  ==  rawbits(v) + DOUBLE_OFFSET      (DOUBLE_OFFSET = 1<<48)
 *     heap ptr p  ==  p                               (arena lives below 1<<48)
 *
 * so any heap cell address is a bare pointer and any engine number carries the
 * offset. Arrays specialize their backing store by elements kind: a DOUBLE
 * array stores unboxed raw doubles, an OBJECT array stores boxed cell values.
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <endian.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

/* ------------------------------------------------------------------ model */

typedef uint64_t Value;

#define DOUBLE_OFFSET 0x0001000000000000ULL   /* 1 << 48 */

#define ARENA_BASE 0x4141000000ULL
#define ARENA_SIZE (64ULL * 1024 * 1024)

#define KIND_DOUBLE 0u
#define KIND_OBJECT 1u

#define CELL_ARRAY 0u
#define CELL_FUNC  1u

static uint8_t *g_arena;
static uint64_t g_arena_off;
static int      g_conn;

static void *arena_alloc(size_t n)
{
    n = (n + 7) & ~(size_t)7;
    if (g_arena_off + n > ARENA_SIZE)
        _exit(2);
    void *p = g_arena + g_arena_off;
    g_arena_off += n;
    return p;
}

/* Array cell layout:
 *   +0  u32 celltype (CELL_ARRAY)
 *   +4  u32 kind
 *   +8  u32 length
 *   +12 u32 capacity
 *   +16 u64 elements (pointer into arena)
 */
typedef struct {
    uint32_t celltype;
    uint32_t kind;
    uint32_t length;
    uint32_t capacity;
    uint64_t *elements;
} Array;

/* Function cell layout:
 *   +0  u32 celltype (CELL_FUNC)
 *   +4  u32 funcidx
 *   +8  u64 code (native entry, or 0)
 */
typedef struct {
    uint32_t celltype;
    uint32_t funcidx;
    uint64_t code;
} FuncCell;

static inline int    val_is_ptr(Value v)    { return v != 0 && v < (1ULL << 48); }
static inline Value  box_double_raw(uint64_t raw) { return raw + DOUBLE_OFFSET; }
static inline uint64_t unbox_raw(Value v)   { return v - DOUBLE_OFFSET; }

static inline double val_to_num(Value v)
{
    uint64_t raw = unbox_raw(v);
    double d;
    memcpy(&d, &raw, 8);
    return d;
}
static inline Value num_to_val(double d)
{
    uint64_t raw;
    memcpy(&raw, &d, 8);
    return box_double_raw(raw);
}

static Array *new_array(uint32_t cap, uint32_t kind)
{
    Array *a = arena_alloc(sizeof(Array));
    a->celltype = CELL_ARRAY;
    a->kind = kind;
    a->length = 0;
    a->capacity = cap;
    a->elements = arena_alloc((cap ? cap : 1) * 8);
    return a;
}

/* Store with element-kind transition. A store of a value whose representation
 * does not match the current kind flips the array's kind and rewrites the slot
 * in the new representation. */
static void store_elem(Array *a, uint32_t idx, Value v)
{
    if (idx >= a->capacity)
        return;
    if (val_is_ptr(v)) {
        a->kind = KIND_OBJECT;
        a->elements[idx] = v;
    } else {
        a->kind = KIND_DOUBLE;
        a->elements[idx] = unbox_raw(v);
    }
    if (idx + 1 > a->length)
        a->length = idx + 1;
}

static Value load_elem(Array *a, uint32_t idx)
{
    if (idx >= a->capacity)
        return num_to_val(0.0);
    if (a->kind == KIND_DOUBLE)
        return box_double_raw(a->elements[idx]);
    return a->elements[idx];
}

/* ------------------------------------------------------------- bytecode */

enum {
    OP_PUSHC,     /* push const[imm]                         */
    OP_PUSHL,     /* push local[imm]                         */
    OP_STOREL,    /* local[imm] = pop                        */
    OP_PUSHG,     /* push global[imm]                        */
    OP_GETIDX,    /* idx=pop base=pop push base[idx]         */
    OP_SETIDX,    /* val=pop idx=pop base=pop base[idx]=val  */
    OP_NEWARR,    /* pop imm elems -> array                  */
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD,
    OP_LT, OP_GT, OP_EQ, OP_NE,
    OP_JMP,       /* pc = imm                                */
    OP_JZ,        /* if !pop pc = imm                        */
    OP_CALL,      /* callee+imm args on stack                */
    OP_RET,       /* return pop                              */
    OP_POP
};

typedef struct {
    uint16_t op;
    int32_t  imm;
} Insn;

#define MAX_CODE   4096
#define MAX_CONST  512
#define MAX_FUNC   64
#define MAX_GLOBAL 128
#define MAX_LOCAL  64

typedef struct {
    Insn     code[MAX_CODE];
    int      ncode;
    Value    consts[MAX_CONST];
    int      nconst;
    int      nparams;
    int      nlocals;
    int      builtin;     /* >=0 for builtins, else -1 */
    uint64_t code_native; /* mirror of the FuncCell code */
    int      hot;
    int      no_jit;
    uint32_t observed_kind;
    FuncCell *cell;
} Func;

static Func   g_funcs[MAX_FUNC];
static int    g_nfunc;

static Value  g_globals[MAX_GLOBAL];
static char   g_gnames[MAX_GLOBAL][32];
static int    g_nglobal;

/* ------------------------------------------------------------- lexer */

typedef enum {
    T_EOF, T_NUM, T_ID, T_LP, T_RP, T_LB, T_RB, T_LC, T_RC,
    T_SEMI, T_COMMA, T_ASSIGN, T_PLUS, T_MINUS, T_STAR, T_SLASH,
    T_PCT, T_LT, T_GT, T_EQ, T_NE,
    T_VAR, T_FUNCTION, T_RETURN, T_WHILE, T_IF, T_ELSE
} Tok;

static const char *g_src;
static size_t g_pos, g_len;
static Tok    g_tok;
static double g_numval;
static char   g_idval[64];

static void fail(const char *m)
{
    char line[128];
    int k = snprintf(line, sizeof line, "ERROR %s\n", m);
    write(g_conn, line, (size_t)k);
    _exit(0);
}

static void skip_ws(void)
{
    for (;;) {
        while (g_pos < g_len && (g_src[g_pos] == ' ' || g_src[g_pos] == '\t' ||
                                 g_src[g_pos] == '\n' || g_src[g_pos] == '\r'))
            g_pos++;
        if (g_pos + 1 < g_len && g_src[g_pos] == '/' && g_src[g_pos + 1] == '/') {
            while (g_pos < g_len && g_src[g_pos] != '\n')
                g_pos++;
            continue;
        }
        break;
    }
}

static void next(void)
{
    skip_ws();
    if (g_pos >= g_len) { g_tok = T_EOF; return; }
    char c = g_src[g_pos];

    if ((c >= '0' && c <= '9') || c == '.') {
        size_t s = g_pos;
        while (g_pos < g_len &&
               ((g_src[g_pos] >= '0' && g_src[g_pos] <= '9') ||
                g_src[g_pos] == '.'))
            g_pos++;
        char buf[64];
        size_t n = g_pos - s;
        if (n >= sizeof buf) fail("number too long");
        memcpy(buf, g_src + s, n);
        buf[n] = 0;
        g_numval = strtod(buf, NULL);
        g_tok = T_NUM;
        return;
    }
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_') {
        size_t s = g_pos;
        while (g_pos < g_len &&
               ((g_src[g_pos] >= 'a' && g_src[g_pos] <= 'z') ||
                (g_src[g_pos] >= 'A' && g_src[g_pos] <= 'Z') ||
                (g_src[g_pos] >= '0' && g_src[g_pos] <= '9') ||
                g_src[g_pos] == '_'))
            g_pos++;
        size_t n = g_pos - s;
        if (n >= sizeof g_idval) fail("identifier too long");
        memcpy(g_idval, g_src + s, n);
        g_idval[n] = 0;
        if (!strcmp(g_idval, "var")) g_tok = T_VAR;
        else if (!strcmp(g_idval, "function")) g_tok = T_FUNCTION;
        else if (!strcmp(g_idval, "return")) g_tok = T_RETURN;
        else if (!strcmp(g_idval, "while")) g_tok = T_WHILE;
        else if (!strcmp(g_idval, "if")) g_tok = T_IF;
        else if (!strcmp(g_idval, "else")) g_tok = T_ELSE;
        else g_tok = T_ID;
        return;
    }
    g_pos++;
    switch (c) {
    case '(': g_tok = T_LP; return;
    case ')': g_tok = T_RP; return;
    case '[': g_tok = T_LB; return;
    case ']': g_tok = T_RB; return;
    case '{': g_tok = T_LC; return;
    case '}': g_tok = T_RC; return;
    case ';': g_tok = T_SEMI; return;
    case ',': g_tok = T_COMMA; return;
    case '+': g_tok = T_PLUS; return;
    case '-': g_tok = T_MINUS; return;
    case '*': g_tok = T_STAR; return;
    case '/': g_tok = T_SLASH; return;
    case '%': g_tok = T_PCT; return;
    case '<': g_tok = T_LT; return;
    case '>': g_tok = T_GT; return;
    case '=':
        if (g_pos < g_len && g_src[g_pos] == '=') { g_pos++; g_tok = T_EQ; return; }
        g_tok = T_ASSIGN; return;
    case '!':
        if (g_pos < g_len && g_src[g_pos] == '=') { g_pos++; g_tok = T_NE; return; }
        fail("unexpected '!'"); return;
    default:
        fail("bad character");
    }
}

static void expect(Tok t, const char *m)
{
    if (g_tok != t) fail(m);
    next();
}

/* --------------------------------------------------------- compiler */

typedef struct {
    char name[32];
} LocalName;

static Func      *cur;
static LocalName  cur_locals[MAX_LOCAL];
static int        cur_nlocal;

static int emit(uint16_t op, int32_t imm)
{
    if (cur->ncode >= MAX_CODE) fail("program too large");
    cur->code[cur->ncode].op = op;
    cur->code[cur->ncode].imm = imm;
    return cur->ncode++;
}

static int add_const(Value v)
{
    if (cur->nconst >= MAX_CONST) fail("too many constants");
    cur->consts[cur->nconst] = v;
    return cur->nconst++;
}

static int local_index(const char *name)
{
    for (int i = 0; i < cur_nlocal; i++)
        if (!strcmp(cur_locals[i].name, name))
            return i;
    return -1;
}

static int local_declare(const char *name)
{
    int i = local_index(name);
    if (i >= 0) return i;
    if (cur_nlocal >= MAX_LOCAL) fail("too many locals");
    snprintf(cur_locals[cur_nlocal].name, sizeof cur_locals[0].name, "%s", name);
    return cur_nlocal++;
}

static int global_index(const char *name)
{
    for (int i = 0; i < g_nglobal; i++)
        if (!strcmp(g_gnames[i], name))
            return i;
    return -1;
}

static void parse_expr(void);

static void parse_primary(void)
{
    if (g_tok == T_NUM) {
        int c = add_const(num_to_val(g_numval));
        emit(OP_PUSHC, c);
        next();
        return;
    }
    if (g_tok == T_LP) {
        next();
        parse_expr();
        expect(T_RP, "expected ')'");
        return;
    }
    if (g_tok == T_LB) {
        next();
        int n = 0;
        if (g_tok != T_RB) {
            parse_expr();
            n++;
            while (g_tok == T_COMMA) { next(); parse_expr(); n++; }
        }
        expect(T_RB, "expected ']'");
        emit(OP_NEWARR, n);
        return;
    }
    if (g_tok == T_ID) {
        char name[64];
        snprintf(name, sizeof name, "%s", g_idval);
        next();
        if (g_tok == T_LP) {
            /* call */
            int gi = global_index(name);
            if (gi < 0) fail("unknown function");
            emit(OP_PUSHG, gi);
            next();
            int argc = 0;
            if (g_tok != T_RP) {
                parse_expr();
                argc++;
                while (g_tok == T_COMMA) { next(); parse_expr(); argc++; }
            }
            expect(T_RP, "expected ')'");
            emit(OP_CALL, argc);
            return;
        }
        int li = local_index(name);
        if (li >= 0) emit(OP_PUSHL, li);
        else {
            int gi = global_index(name);
            if (gi < 0) fail("undefined variable");
            emit(OP_PUSHG, gi);
        }
        /* indexing */
        while (g_tok == T_LB) {
            next();
            parse_expr();
            expect(T_RB, "expected ']'");
            emit(OP_GETIDX, 0);
        }
        return;
    }
    fail("unexpected token in expression");
}

static void parse_mul(void)
{
    parse_primary();
    while (g_tok == T_STAR || g_tok == T_SLASH || g_tok == T_PCT) {
        Tok o = g_tok;
        next();
        parse_primary();
        emit(o == T_STAR ? OP_MUL : o == T_SLASH ? OP_DIV : OP_MOD, 0);
    }
}

static void parse_add(void)
{
    parse_mul();
    while (g_tok == T_PLUS || g_tok == T_MINUS) {
        Tok o = g_tok;
        next();
        parse_mul();
        emit(o == T_PLUS ? OP_ADD : OP_SUB, 0);
    }
}

static void parse_expr(void)
{
    parse_add();
    while (g_tok == T_LT || g_tok == T_GT || g_tok == T_EQ || g_tok == T_NE) {
        Tok o = g_tok;
        next();
        parse_add();
        emit(o == T_LT ? OP_LT : o == T_GT ? OP_GT :
             o == T_EQ ? OP_EQ : OP_NE, 0);
    }
}

static void parse_block(void);

static void parse_statement(void)
{
    if (g_tok == T_LC) { parse_block(); return; }

    if (g_tok == T_VAR) {
        next();
        if (g_tok != T_ID) fail("expected name");
        char name[64];
        snprintf(name, sizeof name, "%s", g_idval);
        next();
        int li = local_declare(name);
        if (g_tok == T_ASSIGN) {
            next();
            parse_expr();
            emit(OP_STOREL, li);
        }
        expect(T_SEMI, "expected ';'");
        return;
    }

    if (g_tok == T_RETURN) {
        next();
        if (g_tok == T_SEMI) {
            int c = add_const(num_to_val(0.0));
            emit(OP_PUSHC, c);
        } else {
            parse_expr();
        }
        expect(T_SEMI, "expected ';'");
        emit(OP_RET, 0);
        return;
    }

    if (g_tok == T_WHILE) {
        next();
        expect(T_LP, "expected '('");
        int top = cur->ncode;
        parse_expr();
        expect(T_RP, "expected ')'");
        int jz = emit(OP_JZ, 0);
        parse_statement();
        emit(OP_JMP, top);
        cur->code[jz].imm = cur->ncode;
        return;
    }

    if (g_tok == T_IF) {
        next();
        expect(T_LP, "expected '('");
        parse_expr();
        expect(T_RP, "expected ')'");
        int jz = emit(OP_JZ, 0);
        parse_statement();
        if (g_tok == T_ELSE) {
            next();
            int jmp = emit(OP_JMP, 0);
            cur->code[jz].imm = cur->ncode;
            parse_statement();
            cur->code[jmp].imm = cur->ncode;
        } else {
            cur->code[jz].imm = cur->ncode;
        }
        return;
    }

    /* identifier: assignment or expression statement */
    if (g_tok == T_ID) {
        char name[64];
        snprintf(name, sizeof name, "%s", g_idval);
        size_t save_pos = g_pos;
        Tok   save_tok = g_tok;
        next();

        if (g_tok == T_ASSIGN) {
            next();
            int li = local_index(name);
            if (li < 0) li = local_declare(name);
            parse_expr();
            emit(OP_STOREL, li);
            expect(T_SEMI, "expected ';'");
            return;
        }
        if (g_tok == T_LB) {
            /* base[idx] = expr   or   expression stmt */
            int li = local_index(name);
            if (li >= 0) emit(OP_PUSHL, li);
            else {
                int gi = global_index(name);
                if (gi < 0) fail("undefined variable");
                emit(OP_PUSHG, gi);
            }
            next();
            parse_expr();
            expect(T_RB, "expected ']'");
            if (g_tok == T_ASSIGN) {
                next();
                parse_expr();
                emit(OP_SETIDX, 0);
                expect(T_SEMI, "expected ';'");
                return;
            }
            emit(OP_GETIDX, 0);
            while (g_tok == T_LB) {
                next(); parse_expr(); expect(T_RB, "expected ']'");
                emit(OP_GETIDX, 0);
            }
            emit(OP_POP, 0);
            expect(T_SEMI, "expected ';'");
            return;
        }

        /* rewind: it was a plain expression statement starting with id */
        g_pos = save_pos;
        g_tok = save_tok;
        snprintf(g_idval, sizeof g_idval, "%s", name);
        parse_expr();
        emit(OP_POP, 0);
        expect(T_SEMI, "expected ';'");
        return;
    }

    parse_expr();
    emit(OP_POP, 0);
    expect(T_SEMI, "expected ';'");
}

static void parse_block(void)
{
    expect(T_LC, "expected '{'");
    while (g_tok != T_RC && g_tok != T_EOF)
        parse_statement();
    expect(T_RC, "expected '}'");
}

static FuncCell *make_func_cell(int funcidx)
{
    FuncCell *fc = arena_alloc(sizeof(FuncCell));
    fc->celltype = CELL_FUNC;
    fc->funcidx = (uint32_t)funcidx;
    fc->code = 0;
    return fc;
}

static void parse_function(void)
{
    next(); /* 'function' */
    if (g_tok != T_ID) fail("expected function name");
    char name[64];
    snprintf(name, sizeof name, "%s", g_idval);
    next();

    if (g_nfunc >= MAX_FUNC) fail("too many functions");
    int fidx = g_nfunc++;
    Func *f = &g_funcs[fidx];
    memset(f, 0, sizeof *f);
    f->builtin = -1;
    f->observed_kind = KIND_DOUBLE;

    /* bind global name before body so recursion resolves */
    if (g_nglobal >= MAX_GLOBAL) fail("too many globals");
    int gi = global_index(name);
    if (gi < 0) {
        gi = g_nglobal++;
        snprintf(g_gnames[gi], sizeof g_gnames[0], "%s", name);
    }
    FuncCell *fc = make_func_cell(fidx);
    g_globals[gi] = (Value)(uintptr_t)fc;
    f->cell = fc;

    Func *prev = cur;
    LocalName prev_locals[MAX_LOCAL];
    int prev_nlocal = cur_nlocal;
    memcpy(prev_locals, cur_locals, sizeof prev_locals);

    cur = f;
    cur_nlocal = 0;

    expect(T_LP, "expected '('");
    int np = 0;
    if (g_tok != T_RP) {
        if (g_tok != T_ID) fail("expected param");
        local_declare(g_idval);
        np++;
        next();
        while (g_tok == T_COMMA) {
            next();
            if (g_tok != T_ID) fail("expected param");
            local_declare(g_idval);
            np++;
            next();
        }
    }
    expect(T_RP, "expected ')'");
    f->nparams = np;

    parse_block();
    int c = add_const(num_to_val(0.0));
    emit(OP_PUSHC, c);
    emit(OP_RET, 0);
    f->nlocals = cur_nlocal;

    cur = prev;
    cur_nlocal = prev_nlocal;
    memcpy(cur_locals, prev_locals, sizeof cur_locals);
}

/* ------------------------------------------------------- JIT: IR + passes */

static Value cur_const_value(Func *f, int cidx);

enum { IR_ARG, IR_CONST, IR_CHECKMAP, IR_GETELEM, IR_SETELEM, IR_RET };

typedef struct {
    int      op;
    int      a;     /* operand ir ref / arg index / const value  */
    int      b;     /* index / local                              */
    int      c;     /* operand ir ref                             */
    uint32_t kind;  /* pinned elements kind for GET/CHECK         */
    int      dead;
    int      removed;
} IR;

#define MAX_IR 64

typedef struct {
    IR   n[MAX_IR];
    int  count;
    int  stack[MAX_IR];
    int  sp;
    int  locals[MAX_LOCAL];
    int  ok;
} IRB;

static int ir_emit(IRB *b, int op, int a, int c, uint32_t kind)
{
    if (b->count >= MAX_IR) { b->ok = 0; return -1; }
    IR *n = &b->n[b->count];
    n->op = op; n->a = a; n->b = 0; n->c = c; n->kind = kind;
    n->dead = 0; n->removed = 0;
    return b->count++;
}

static void ir_push(IRB *b, int ref) { if (b->sp < MAX_IR) b->stack[b->sp++] = ref; else b->ok = 0; }
static int  ir_pop(IRB *b)  { return b->sp > 0 ? b->stack[--b->sp] : (b->ok = 0, 0); }

/* Build IR for a straight-line function body. Any opcode outside the small
 * supported set aborts JIT compilation and the function stays interpreted. */
static int ir_build(Func *f, IRB *b)
{
    b->count = b->sp = 0;
    b->ok = 1;
    for (int i = 0; i < MAX_LOCAL; i++) b->locals[i] = -1;

    for (int pc = 0; pc < f->ncode; pc++) {
        Insn *in = &f->code[pc];
        switch (in->op) {
        case OP_PUSHL: {
            int ref = b->locals[in->imm];
            if (ref < 0) {
                if (in->imm < f->nparams)
                    ref = ir_emit(b, IR_ARG, in->imm, 0, 0);
                else
                    return 0;
                b->locals[in->imm] = ref;
            }
            ir_push(b, ref);
            break;
        }
        case OP_PUSHC: {
            int ref = ir_emit(b, IR_CONST, in->imm, 0, 0);
            ir_push(b, ref);
            break;
        }
        case OP_STOREL: {
            int v = ir_pop(b);
            b->locals[in->imm] = v;
            break;
        }
        case OP_GETIDX: {
            int idx = ir_pop(b);
            int base = ir_pop(b);
            if (b->n[idx].op != IR_CONST) return 0;
            int cidx = (int)val_to_num(cur_const_value(f, b->n[idx].a));
            int chk = ir_emit(b, IR_CHECKMAP, base, 0, f->observed_kind);
            (void)chk;
            int g = ir_emit(b, IR_GETELEM, base, cidx, f->observed_kind);
            ir_push(b, g);
            break;
        }
        case OP_SETIDX: {
            int val = ir_pop(b);
            int idx = ir_pop(b);
            int base = ir_pop(b);
            if (b->n[idx].op != IR_CONST) return 0;
            int cidx = (int)val_to_num(cur_const_value(f, b->n[idx].a));
            ir_emit(b, IR_CHECKMAP, base, 0, f->observed_kind);
            IR *s = &b->n[ir_emit(b, IR_SETELEM, base, val, f->observed_kind)];
            s->b = cidx;
            break;
        }
        case OP_RET: {
            int v = ir_pop(b);
            ir_emit(b, IR_RET, v, 0, 0);
            if (!b->ok) return 0;
            return 1;
        }
        default:
            return 0; /* unsupported op */
        }
        if (!b->ok) return 0;
    }
    return 0;
}

static Value cur_const_value(Func *f, int cidx)
{
    return f->consts[cidx];
}

/* Pass A (decoy): fold a redundant load that reuses an earlier GETELEM result
 * on the same base and index when nothing between them writes that base. It
 * only rewrites values, never a map assumption, so it is inert for safety. */
static void pass_load_cse(IRB *b)
{
    for (int i = 0; i < b->count; i++) {
        if (b->n[i].op != IR_GETELEM) continue;
        for (int j = 0; j < i; j++) {
            if (b->n[j].op != IR_GETELEM) continue;
            if (b->n[j].a != b->n[i].a || b->n[j].b != b->n[i].b) continue;
            int clobber = 0;
            for (int k = j + 1; k < i; k++)
                if (b->n[k].op == IR_SETELEM && b->n[k].a == b->n[i].a)
                    clobber = 1;
            if (!clobber)
                b->n[i].dead = 1; /* value-only reuse; result aliased to j */
        }
    }
}

/* Pass B: eliminate a CheckMap that is dominated by an earlier CheckMap on the
 * same base value. A barrier clears the proven set. */
static int is_barrier(int op)
{
    return op == IR_RET; /* calls would also clear here; none in-region */
}

static void pass_checkmap_elim(IRB *b)
{
    int proven[MAX_IR];
    int nproven = 0;
    for (int i = 0; i < b->count; i++) {
        IR *n = &b->n[i];
        if (is_barrier(n->op)) { nproven = 0; continue; }
        if (n->op != IR_CHECKMAP) continue;
        int base = n->a;
        int found = 0;
        for (int p = 0; p < nproven; p++)
            if (proven[p] == base) { found = 1; break; }
        if (found) {
            n->removed = 1;
        } else if (nproven < MAX_IR) {
            proven[nproven++] = base;
        }
    }
}

/* ------------------------------------------------------- JIT: x86-64 emit */

typedef struct {
    uint8_t *buf;
    int      len;
    int      cap;
    int      bail_sites[64];
    int      nbail;
    int      epi_sites[64];
    int      nepi;
} Asm;

static void e8(Asm *a, uint8_t x) { a->buf[a->len++] = x; }
static void e32(Asm *a, uint32_t x)
{
    e8(a, x & 0xff); e8(a, (x >> 8) & 0xff);
    e8(a, (x >> 16) & 0xff); e8(a, (x >> 24) & 0xff);
}
static void e64(Asm *a, uint64_t x) { e32(a, (uint32_t)x); e32(a, (uint32_t)(x >> 32)); }
static uint8_t d8(int neg) { return (uint8_t)(256 - neg); }

static int slot_disp(int ir_ref) { return 40 + ir_ref * 8; } /* [rbp - disp] */

static Value run_interpreted(void *vm, FuncCell *fc, Value *args, uint64_t nargs);

/* mov rax, [rbp - disp]  (disp32 form) */
static void emit_load_slot(Asm *a, int reg_dst_is_rax_only, int ir_ref)
{
    (void)reg_dst_is_rax_only;
    e8(a, 0x48); e8(a, 0x8b); e8(a, 0x85);
    e32(a, (uint32_t)(-slot_disp(ir_ref)));
}
/* mov [rbp - disp], rax  (disp32 form) */
static void emit_store_rax_slot(Asm *a, int ir_ref)
{
    e8(a, 0x48); e8(a, 0x89); e8(a, 0x85);
    e32(a, (uint32_t)(-slot_disp(ir_ref)));
}

static void jit_emit(Func *f, IRB *b)
{
    Asm as;
    memset(&as, 0, sizeof as);
    as.cap = 4096;
    as.buf = mmap(NULL, as.cap, PROT_READ | PROT_WRITE | PROT_EXEC,
                  MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (as.buf == MAP_FAILED) { f->no_jit = 1; return; }
    Asm *a = &as;

    /* prologue */
    e8(a, 0x55);                             /* push rbp                 */
    e8(a, 0x48); e8(a, 0x89); e8(a, 0xe5);   /* mov rbp, rsp             */
    e8(a, 0x48); e8(a, 0x81); e8(a, 0xec); e32(a, 512); /* sub rsp, 512  */
    e8(a, 0x48); e8(a, 0x89); e8(a, 0x7d); e8(a, d8(8));   /* [rbp-8]=rdi vm   */
    e8(a, 0x48); e8(a, 0x89); e8(a, 0x75); e8(a, d8(16));  /* [rbp-16]=rsi fc  */
    e8(a, 0x48); e8(a, 0x89); e8(a, 0x55); e8(a, d8(24));  /* [rbp-24]=rdx args*/
    e8(a, 0x48); e8(a, 0x89); e8(a, 0x4d); e8(a, d8(32));  /* [rbp-32]=rcx narg*/

    for (int i = 0; i < b->count; i++) {
        IR *n = &b->n[i];
        if (n->removed) continue;
        switch (n->op) {
        case IR_ARG:
            e8(a, 0x48); e8(a, 0x8b); e8(a, 0x45); e8(a, d8(24));  /* mov rax,[rbp-24] */
            e8(a, 0x48); e8(a, 0x8b); e8(a, 0x40); e8(a, (uint8_t)(8 * n->a)); /* mov rax,[rax+8k] */
            emit_store_rax_slot(a, i);
            break;
        case IR_CONST:
            e8(a, 0x48); e8(a, 0xb8); e64(a, f->consts[n->a]);     /* mov rax, imm64 */
            emit_store_rax_slot(a, i);
            break;
        case IR_CHECKMAP:
            emit_load_slot(a, 1, n->a);                            /* mov rax,[base]  */
            e8(a, 0x81); e8(a, 0x78); e8(a, 0x04); e32(a, n->kind);/* cmp [rax+4],kind*/
            e8(a, 0x0f); e8(a, 0x85); e32(a, 0);                   /* jne rel32       */
            as.bail_sites[as.nbail++] = a->len - 4;
            break;
        case IR_GETELEM:
            if (n->dead) break;
            emit_load_slot(a, 1, n->a);                            /* mov rax,[base]  */
            e8(a, 0x48); e8(a, 0x8b); e8(a, 0x40); e8(a, 16);      /* mov rax,[rax+16]*/
            e8(a, 0x48); e8(a, 0x8b); e8(a, 0x40); e8(a, (uint8_t)(8 * n->b)); /* mov rax,[rax+8*idx] */
            if (n->kind == KIND_DOUBLE) {
                e8(a, 0x48); e8(a, 0xb9); e64(a, DOUBLE_OFFSET);   /* mov rcx,OFFSET  */
                e8(a, 0x48); e8(a, 0x01); e8(a, 0xc8);             /* add rax,rcx     */
            }
            emit_store_rax_slot(a, i);
            break;
        case IR_SETELEM:
            emit_load_slot(a, 1, n->a);                            /* mov rax,[base]  */
            e8(a, 0x48); e8(a, 0x89); e8(a, 0xc7);                 /* mov rdi,rax     */
            e8(a, 0xbe); e32(a, (uint32_t)n->b);                   /* mov esi, idx    */
            e8(a, 0x48); e8(a, 0x8b); e8(a, 0x95);                 /* mov rdx,[rbp-d] */
            e32(a, (uint32_t)(-slot_disp(n->c)));
            e8(a, 0x48); e8(a, 0xb8); e64(a, (uint64_t)(uintptr_t)store_elem); /* mov rax,&store_elem */
            e8(a, 0xff); e8(a, 0xd0);                              /* call rax        */
            break;
        case IR_RET:
            emit_load_slot(a, 1, n->a);                            /* mov rax,[v]     */
            e8(a, 0xe9); e32(a, 0);                                /* jmp epilogue    */
            as.epi_sites[as.nepi++] = a->len - 4;
            break;
        }
    }

    /* bail block */
    int bail_pos = a->len;
    e8(a, 0x48); e8(a, 0x8b); e8(a, 0x7d); e8(a, d8(8));   /* mov rdi,[rbp-8]  */
    e8(a, 0x48); e8(a, 0x8b); e8(a, 0x75); e8(a, d8(16));  /* mov rsi,[rbp-16] */
    e8(a, 0x48); e8(a, 0x8b); e8(a, 0x55); e8(a, d8(24));  /* mov rdx,[rbp-24] */
    e8(a, 0x48); e8(a, 0x8b); e8(a, 0x4d); e8(a, d8(32));  /* mov rcx,[rbp-32] */
    e8(a, 0x48); e8(a, 0xb8); e64(a, (uint64_t)(uintptr_t)run_interpreted);
    e8(a, 0xff); e8(a, 0xd0);                              /* call rax         */
    e8(a, 0xe9); e32(a, 0);                                /* jmp epilogue     */
    as.epi_sites[as.nepi++] = a->len - 4;

    int epi_pos = a->len;
    e8(a, 0xc9);                                           /* leave            */
    e8(a, 0xc3);                                           /* ret              */

    for (int i = 0; i < as.nbail; i++) {
        int site = as.bail_sites[i];
        int32_t rel = bail_pos - (site + 4);
        memcpy(a->buf + site, &rel, 4);
    }
    for (int i = 0; i < as.nepi; i++) {
        int site = as.epi_sites[i];
        int32_t rel = epi_pos - (site + 4);
        memcpy(a->buf + site, &rel, 4);
    }

    f->code_native = (uint64_t)(uintptr_t)a->buf;
    f->cell->code = f->code_native;
}

static void jit_compile(Func *f)
{
    if (f->no_jit) return;
    IRB b;
    if (!ir_build(f, &b) || !b.ok) { f->no_jit = 1; return; }
    if (b.count > 60) { f->no_jit = 1; return; }
    pass_load_cse(&b);
    pass_checkmap_elim(&b);
    jit_emit(f, &b);
    if (!f->code_native) f->no_jit = 1;
}

/* ------------------------------------------------------- interpreter */

#define HOT 50
#define MAX_DEPTH 64
#define STEP_LIMIT 20000000

typedef uint64_t (*jitfn)(void *vm, FuncCell *fc, Value *args, uint64_t nargs);

static long g_steps;
static int  g_depth;

static Value call_builtin(int id, Value *args, int argc);
static Value interp_exec(Func *f, FuncCell *fc, Value *args, uint64_t nargs);

static Value run_func(FuncCell *fc, Value *args, uint64_t nargs)
{
    Func *f = &g_funcs[fc->funcidx];

    if (f->builtin >= 0)
        return call_builtin(f->builtin, args, (int)nargs);

    if (g_depth >= MAX_DEPTH) fail("call depth exceeded");

    if (f->code_native) {
        g_depth++;
        Value r = ((jitfn)(uintptr_t)f->code_native)(NULL, fc, args, nargs);
        g_depth--;
        return r;
    }

    f->hot++;
    if (!f->no_jit && !f->code_native && f->hot >= HOT) {
        jit_compile(f);
        if (f->code_native) {
            g_depth++;
            Value r = ((jitfn)(uintptr_t)f->code_native)(NULL, fc, args, nargs);
            g_depth--;
            return r;
        }
    }

    return interp_exec(f, fc, args, nargs);
}

/* Entry used by a JIT bailout: always runs the bytecode, never re-dispatches
 * to native code. */
static Value run_interpreted(void *vm, FuncCell *fc, Value *args, uint64_t nargs)
{
    (void)vm;
    Func *f = &g_funcs[fc->funcidx];
    return interp_exec(f, fc, args, nargs);
}

static Value interp_exec(Func *f, FuncCell *fc, Value *args, uint64_t nargs)
{
    (void)fc;
    Value locals[MAX_LOCAL];
    for (int i = 0; i < f->nlocals; i++)
        locals[i] = ((uint64_t)i < nargs) ? args[i] : num_to_val(0.0);

    Value stack[256];
    int sp = 0;
    int pc = 0;

    g_depth++;
    while (pc < f->ncode) {
        if (++g_steps > STEP_LIMIT) fail("step limit");
        Insn *in = &f->code[pc++];
        switch (in->op) {
        case OP_PUSHC: stack[sp++] = f->consts[in->imm]; break;
        case OP_PUSHL: stack[sp++] = locals[in->imm]; break;
        case OP_PUSHG: stack[sp++] = g_globals[in->imm]; break;
        case OP_STOREL: locals[in->imm] = stack[--sp]; break;
        case OP_POP: sp--; break;
        case OP_NEWARR: {
            int nn = in->imm;
            uint32_t cap = nn < 4 ? 32 : (uint32_t)nn + 16;
            Array *arr = new_array(cap, KIND_DOUBLE);
            for (int i = nn - 1; i >= 0; i--)
                store_elem(arr, (uint32_t)i, stack[--sp]);
            arr->length = (uint32_t)nn;
            stack[sp++] = (Value)(uintptr_t)arr;
            break;
        }
        case OP_GETIDX: {
            Value iv = stack[--sp];
            Value bv = stack[--sp];
            if (!val_is_ptr(bv)) fail("index of non-object");
            Array *arr = (Array *)(uintptr_t)bv;
            uint32_t idx = (uint32_t)val_to_num(iv);
            f->observed_kind = arr->kind;
            stack[sp++] = load_elem(arr, idx);
            break;
        }
        case OP_SETIDX: {
            Value vv = stack[--sp];
            Value iv = stack[--sp];
            Value bv = stack[--sp];
            if (!val_is_ptr(bv)) fail("index of non-object");
            Array *arr = (Array *)(uintptr_t)bv;
            uint32_t idx = (uint32_t)val_to_num(iv);
            f->observed_kind = arr->kind;
            store_elem(arr, idx, vv);
            break;
        }
        case OP_ADD: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val(x + y); break; }
        case OP_SUB: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val(x - y); break; }
        case OP_MUL: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val(x * y); break; }
        case OP_DIV: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val(x / y); break; }
        case OP_MOD: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val((double)((long long)x % (long long)(y == 0 ? 1 : y))); break; }
        case OP_LT: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val(x < y ? 1.0 : 0.0); break; }
        case OP_GT: { double y = val_to_num(stack[--sp]); double x = val_to_num(stack[--sp]); stack[sp++] = num_to_val(x > y ? 1.0 : 0.0); break; }
        case OP_EQ: { Value y = stack[--sp]; Value x = stack[--sp]; stack[sp++] = num_to_val(x == y ? 1.0 : 0.0); break; }
        case OP_NE: { Value y = stack[--sp]; Value x = stack[--sp]; stack[sp++] = num_to_val(x != y ? 1.0 : 0.0); break; }
        case OP_JMP: pc = in->imm; break;
        case OP_JZ: { double c = val_to_num(stack[--sp]); if (c == 0.0) pc = in->imm; break; }
        case OP_CALL: {
            int argc = in->imm;
            Value callee = stack[sp - argc - 1];
            Value *cargs = &stack[sp - argc];
            if (!val_is_ptr(callee)) fail("call of non-function");
            FuncCell *cc = (FuncCell *)(uintptr_t)callee;
            if (cc->celltype != CELL_FUNC) fail("call of non-function");
            Value r = run_func(cc, cargs, (uint64_t)argc);
            sp -= argc + 1;
            stack[sp++] = r;
            break;
        }
        case OP_RET: {
            Value r = stack[--sp];
            g_depth--;
            return r;
        }
        default: fail("bad opcode");
        }
    }
    g_depth--;
    return num_to_val(0.0);
}

/* ------------------------------------------------------- builtins */

enum { B_U64, B_HI, B_LO, B_FLOOR, B_SEND };

static Value call_builtin(int id, Value *args, int argc)
{
    switch (id) {
    case B_U64: {
        uint64_t hi = argc > 0 ? (uint64_t)(int64_t)val_to_num(args[0]) : 0;
        uint64_t lo = argc > 1 ? (uint64_t)(int64_t)val_to_num(args[1]) : 0;
        uint64_t raw = (hi << 32) | (lo & 0xffffffffULL);
        return box_double_raw(raw);
    }
    case B_HI: {
        uint64_t raw = argc > 0 ? unbox_raw(args[0]) : 0;
        return num_to_val((double)(uint32_t)(raw >> 32));
    }
    case B_LO: {
        uint64_t raw = argc > 0 ? unbox_raw(args[0]) : 0;
        return num_to_val((double)(uint32_t)(raw & 0xffffffffULL));
    }
    case B_FLOOR: {
        double x = argc > 0 ? val_to_num(args[0]) : 0;
        double f = (double)(int64_t)x;
        if (f > x) f -= 1.0;
        return num_to_val(f);
    }
    case B_SEND: {
        uint64_t raw = 0;
        if (argc > 0) {
            Value v = args[0];
            raw = val_is_ptr(v) ? v : unbox_raw(v);
        }
        write(g_conn, &raw, 8);
        return num_to_val(0.0);
    }
    }
    return num_to_val(0.0);
}

static void register_builtin(const char *name, int id, int np)
{
    int fidx = g_nfunc++;
    Func *f = &g_funcs[fidx];
    memset(f, 0, sizeof *f);
    f->builtin = id;
    f->nparams = np;
    f->no_jit = 1;
    FuncCell *fc = make_func_cell(fidx);
    f->cell = fc;
    int gi = g_nglobal++;
    snprintf(g_gnames[gi], sizeof g_gnames[0], "%s", name);
    g_globals[gi] = (Value)(uintptr_t)fc;
}

/* ------------------------------------------------------- driver */

static void setup(void)
{
    g_arena = mmap(NULL, ARENA_SIZE, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (g_arena == MAP_FAILED) _exit(3);
    g_arena_off = 0;

    g_nfunc = g_nglobal = 0;
    register_builtin("u64", B_U64, 2);
    register_builtin("hi", B_HI, 1);
    register_builtin("lo", B_LO, 1);
    register_builtin("floor", B_FLOOR, 1);
    register_builtin("send", B_SEND, 1);
}

static int read_full(int fd, void *buf, size_t len)
{
    uint8_t *p = buf;
    size_t got = 0;
    while (got < len) {
        ssize_t n = read(fd, p + got, len - got);
        if (n <= 0) return 0;
        got += (size_t)n;
    }
    return 1;
}

static void handle(int fd)
{
    g_conn = fd;
    dup2(fd, 1);

    uint32_t slen = 0;
    if (!read_full(fd, &slen, 4)) return;
    slen = le32toh(slen);
    if (slen == 0 || slen > 1 << 20) { fail("bad length"); }

    char *src = malloc(slen + 1);
    if (!src) return;
    if (!read_full(fd, src, slen)) return;
    src[slen] = 0;

    setup();

    g_src = src;
    g_pos = 0;
    g_len = slen;
    g_steps = 0;
    g_depth = 0;

    /* top-level is compiled into an implicit main function */
    int fidx = g_nfunc++;
    Func *mainf = &g_funcs[fidx];
    memset(mainf, 0, sizeof *mainf);
    mainf->builtin = -1;
    mainf->no_jit = 1;
    FuncCell *mainc = make_func_cell(fidx);
    mainf->cell = mainc;

    cur = mainf;
    cur_nlocal = 0;

    next();
    while (g_tok != T_EOF) {
        if (g_tok == T_FUNCTION) parse_function();
        else parse_statement();
    }
    int c = add_const(num_to_val(0.0));
    emit(OP_PUSHC, c);
    emit(OP_RET, 0);
    mainf->nlocals = cur_nlocal;

    run_func(mainc, NULL, 0);
    write(fd, "\n", 1);
}

int main(int argc, char **argv)
{
    int port = argc > 1 ? atoi(argv[1]) : 9101;

    signal(SIGCHLD, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);

    int srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0) { perror("socket"); return 1; }
    int one = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);

    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) < 0) { perror("bind"); return 1; }
    if (listen(srv, 16) < 0) { perror("listen"); return 1; }

    for (;;) {
        int fd = accept(srv, NULL, NULL);
        if (fd < 0) continue;
        pid_t pid = fork();
        if (pid == 0) {
            close(srv);
            alarm(3);
            handle(fd);
            shutdown(fd, SHUT_RDWR);
            close(fd);
            _exit(0);
        }
        close(fd);
    }
    return 0;
}
