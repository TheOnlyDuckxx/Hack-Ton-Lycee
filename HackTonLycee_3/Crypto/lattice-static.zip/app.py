"""Static Vault: a post-quantum sealed-vault service.

A module-LWE KEM guards a sealed flag. The public key and the sealed flag
ciphertext are published; a decapsulation endpoint reports whether a submitted
ciphertext decapsulates cleanly.
"""

from __future__ import annotations

import base64
import threading
import time
from collections import deque

from flask import Flask, jsonify, request

import kem

FLAG_PATH = "/srv/flag.txt"


def _load_flag() -> str:
    try:
        with open(FLAG_PATH, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except FileNotFoundError:
        return "HTL{dev_default_latticestatic}"


FLAG = _load_flag()

PK, SK = kem.keygen()
_K_FLAG, FLAG_CT = kem.encaps(PK)
FLAG_BOX = kem.seal(_K_FLAG, FLAG.encode())

app = Flask(__name__)

_RATE_LOCK = threading.Lock()
_RATE_HITS: "deque[float]" = deque()
_RATE_WINDOW = 60.0
_RATE_MAX = 2000


def _rate_ok() -> bool:
    now = time.time()
    with _RATE_LOCK:
        while _RATE_HITS and now - _RATE_HITS[0] > _RATE_WINDOW:
            _RATE_HITS.popleft()
        if len(_RATE_HITS) >= _RATE_MAX:
            return False
        _RATE_HITS.append(now)
        return True


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode()


INDEX = """<!doctype html>
<title>Static Vault</title>
<h1>Static Vault</h1>
<p>A post-quantum sealed vault built on a compact module-LWE KEM over
R_q = Z_q[x]/(x^n + 1). The vault key was encapsulated once at boot; the flag
is sealed under the resulting shared secret and will never be transmitted in
the clear.</p>
<ul>
  <li><code>GET  /pk</code> &mdash; scheme parameters and public key (seed, A, t)</li>
  <li><code>GET  /flag_ct</code> &mdash; the sealed flag: KEM ciphertext + AEAD box</li>
  <li><code>POST /decap</code> &mdash; submit a ciphertext, learn whether it decapsulates</li>
</ul>
<p>Ciphertext wire format: JSON
<code>{"u": [[n ints], ... k rows], "v": [n ints], "tag": "&lt;hex&gt;"}</code>
with all coefficients reduced mod q. Decapsulation recovers
<code>m' = decode(v - s^T u)</code>, recomputes the re-encryption tag
<code>H(m')</code>, and accepts iff it matches the submitted tag.</p>
"""


@app.get("/")
def index():
    return INDEX


@app.get("/healthz")
def healthz():
    return jsonify(status="ok")


@app.get("/pk")
def pk():
    return jsonify(
        scheme="module-LWE KEM over Z_q[x]/(x^n+1)",
        n=kem.N,
        k=kem.K,
        q=kem.Q,
        eta=kem.ETA,
        encode_one=kem.Q2,
        seed=PK.seed.hex(),
        A=PK.A,
        t=PK.t,
    )


@app.get("/flag_ct")
def flag_ct():
    return jsonify(
        ct=FLAG_CT,
        box=_b64(FLAG_BOX),
        note="box = nonce(16) || ciphertext || HMAC-SHA256(32), sealed under KDF(m)",
    )


@app.post("/decap")
def decap():
    if not _rate_ok():
        return jsonify(error="rate limited, slow down"), 429

    data = request.get_json(silent=True) or {}
    try:
        u = [[int(c) for c in row] for row in data["u"]]
        v = [int(c) for c in data["v"]]
        thetag = str(data["tag"])
        bytes.fromhex(thetag)
    except (KeyError, TypeError, ValueError):
        return jsonify(error="expected u[k][n], v[n], tag hex"), 400
    if len(u) != kem.K or any(len(row) != kem.N for row in u) or len(v) != kem.N:
        return jsonify(error="bad ciphertext dimensions"), 400

    ok, _ = kem.decaps(SK, {"u": u, "v": v, "tag": thetag})
    if ok:
        return jsonify(status="ok")
    return jsonify(error="decapsulation failed"), 422


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9002)
