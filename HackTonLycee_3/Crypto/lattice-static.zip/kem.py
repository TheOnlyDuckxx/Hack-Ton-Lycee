"""Static Vault: a compact module-LWE key-encapsulation mechanism.

The scheme follows the familiar LPR / module-LWE recipe over the ring
R_q = Z_q[x] / (x^n + 1):

    keygen:   A <- expand(seed) in R_q^{k x k},  s, e <- CBD_eta
              t = A s + e                       (public key (seed/A, t))
    encaps:   m <- {0,1}^n,  r, e1 <- CBD_eta,  e2 <- CBD_eta
              u = A^T r + e1
              v = t^T r + e2 + encode(m)
              shared key K = KDF(m)
              re-encryption tag  tau = H(m)
              ciphertext = (u, v, tau)
    decaps:   m' = decode(v - s^T u)
              accept iff H(m') == tau, then return K = KDF(m')

Parameters here are bespoke (not a standardised set); the ring degree,
modulus, rank and noise width are all chosen for this deployment.
"""

from __future__ import annotations

import hashlib
import hmac
import os
from typing import List, Tuple

# ---------------------------------------------------------------------------
# parameters
# ---------------------------------------------------------------------------
N = 128           # ring degree, R_q = Z_q[x]/(x^n + 1)
K = 3             # module rank
Q = 3457          # modulus (prime)
ETA = 2           # centred-binomial noise width
Q2 = (Q + 1) // 2  # encode('1')

DOM_XOF = b"lattice-static/xof/v1"
DOM_CBD = b"lattice-static/cbd/v1"
DOM_TAG = b"lattice-static/tag/v1"
DOM_KEY = b"lattice-static/key/v1"
DOM_STREAM = b"lattice-static/stream/v1"
DOM_MAC = b"lattice-static/mac/v1"

Poly = List[int]
Vec = List[Poly]
Mat = List[List[Poly]]


# ---------------------------------------------------------------------------
# ring arithmetic  (negacyclic, schoolbook)
# ---------------------------------------------------------------------------
def poly_add(a: Poly, b: Poly) -> Poly:
    return [(x + y) % Q for x, y in zip(a, b)]


def poly_sub(a: Poly, b: Poly) -> Poly:
    return [(x - y) % Q for x, y in zip(a, b)]


def poly_mul(a: Poly, b: Poly) -> Poly:
    res = [0] * N
    for j in range(N):
        bj = b[j]
        if bj == 0:
            continue
        for i in range(N):
            k = i + j
            if k < N:
                res[k] += a[i] * bj
            else:
                res[k - N] -= a[i] * bj
    return [x % Q for x in res]


def vec_dot(a: Vec, b: Vec) -> Poly:
    acc = [0] * N
    for pa, pb in zip(a, b):
        acc = poly_add(acc, poly_mul(pa, pb))
    return acc


def mat_vec(m: Mat, v: Vec) -> Vec:
    return [vec_dot(row, v) for row in m]


def mat_transpose(m: Mat) -> Mat:
    return [[m[j][i] for j in range(len(m))] for i in range(len(m[0]))]


# ---------------------------------------------------------------------------
# sampling
# ---------------------------------------------------------------------------
def _xof(seed: bytes, i: int, j: int) -> hashlib.shake_256:
    h = hashlib.shake_256()
    h.update(DOM_XOF)
    h.update(seed)
    h.update(bytes([i, j]))
    return h


def sample_uniform(seed: bytes, i: int, j: int) -> Poly:
    xof = _xof(seed, i, j)
    out: Poly = []
    counter = 0
    while len(out) < N:
        block = xof.digest(2 * (N + 32) + counter)[-2 * (N + 32):]
        counter += 64
        for p in range(0, len(block) - 1, 2):
            val = (block[p] | (block[p + 1] << 8)) & 0xFFF
            if val < Q:
                out.append(val)
                if len(out) == N:
                    break
    return out


def expand_matrix(seed: bytes) -> Mat:
    return [[sample_uniform(seed, i, j) for j in range(K)] for i in range(K)]


def _cbd(buf: bytes) -> Poly:
    bits: List[int] = []
    for byte in buf:
        for t in range(8):
            bits.append((byte >> t) & 1)
    out: Poly = []
    idx = 0
    for _ in range(N):
        a = sum(bits[idx:idx + ETA]); idx += ETA
        b = sum(bits[idx:idx + ETA]); idx += ETA
        out.append((a - b) % Q)
    return out


def sample_noise(label: bytes) -> Poly:
    need = (2 * ETA * N + 7) // 8
    h = hashlib.shake_256()
    h.update(DOM_CBD)
    h.update(label)
    return _cbd(h.digest(need))


def noise_vec(prefix: bytes) -> Vec:
    return [sample_noise(prefix + bytes([i])) for i in range(K)]


# ---------------------------------------------------------------------------
# message coding
# ---------------------------------------------------------------------------
def encode(bits: List[int]) -> Poly:
    return [(b & 1) * Q2 for b in bits]


def decode(poly: Poly) -> List[int]:
    lo = Q // 4
    hi = (3 * Q) // 4
    return [1 if lo <= (c % Q) < hi else 0 for c in poly]


def bits_to_bytes(bits: List[int]) -> bytes:
    out = bytearray(N // 8)
    for i, b in enumerate(bits):
        if b & 1:
            out[i >> 3] |= 1 << (i & 7)
    return bytes(out)


def bytes_to_bits(buf: bytes) -> List[int]:
    return [(buf[i >> 3] >> (i & 7)) & 1 for i in range(N)]


# ---------------------------------------------------------------------------
# hashing / KDF / tag
# ---------------------------------------------------------------------------
def tag(bits: List[int]) -> bytes:
    return hashlib.sha256(DOM_TAG + bits_to_bytes(bits)).digest()


def kdf(bits: List[int]) -> bytes:
    return hashlib.sha256(DOM_KEY + bits_to_bytes(bits)).digest()


# ---------------------------------------------------------------------------
# keygen / encaps / decaps
# ---------------------------------------------------------------------------
class SecretKey:
    def __init__(self, s: Vec):
        self.s = s


class PublicKey:
    def __init__(self, seed: bytes, A: Mat, t: Vec):
        self.seed = seed
        self.A = A
        self.t = t


def keygen() -> Tuple[PublicKey, SecretKey]:
    seed = os.urandom(32)
    A = expand_matrix(seed)
    s = noise_vec(b"s" + os.urandom(16))
    e = noise_vec(b"e" + os.urandom(16))
    t = [poly_add(p, ei) for p, ei in zip(mat_vec(A, s), e)]
    return PublicKey(seed, A, t), SecretKey(s)


def encaps(pk: PublicKey) -> Tuple[bytes, dict]:
    m = bytes_to_bits(os.urandom(N // 8))
    seed = os.urandom(16)
    r = noise_vec(b"r" + seed)
    e1 = noise_vec(b"1" + seed)
    e2 = sample_noise(b"2" + seed)

    At = mat_transpose(pk.A)
    u = [poly_add(p, ei) for p, ei in zip(mat_vec(At, r), e1)]
    v = poly_add(poly_add(vec_dot(pk.t, r), e2), encode(m))

    ct = {"u": u, "v": v, "tag": tag(m).hex()}
    return kdf(m), ct


def decaps(sk: SecretKey, ct: dict) -> Tuple[bool, bytes]:
    u = [[c % Q for c in row] for row in ct["u"]]
    v = [c % Q for c in ct["v"]]
    w = poly_sub(v, vec_dot(sk.s, u))
    m = decode(w)
    recomputed = tag(m)
    claimed = bytes.fromhex(ct["tag"])
    if not _equal(recomputed, claimed):
        return False, b""
    return True, kdf(m)


def _equal(a: bytes, b: bytes) -> bool:
    if len(a) != len(b):
        return False
    for x, y in zip(a, b):
        if x != y:
            return False
    return True


# ---------------------------------------------------------------------------
# stream AEAD used to wrap the flag under the KEM shared key
# ---------------------------------------------------------------------------
def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        block = hashlib.sha256(
            DOM_STREAM + key + nonce + counter.to_bytes(8, "big")
        ).digest()
        out.extend(block)
        counter += 1
    return bytes(out[:length])


def seal(key: bytes, pt: bytes) -> bytes:
    nonce = os.urandom(16)
    ct = bytes(a ^ b for a, b in zip(pt, _keystream(key, nonce, len(pt))))
    mac = hmac.new(key, DOM_MAC + nonce + ct, hashlib.sha256).digest()
    return nonce + ct + mac


def open_box(key: bytes, box: bytes) -> bytes:
    nonce, ct, mac = box[:16], box[16:-32], box[-32:]
    expected = hmac.new(key, DOM_MAC + nonce + ct, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expected):
        raise ValueError("authentication failed")
    return bytes(a ^ b for a, b in zip(ct, _keystream(key, nonce, len(ct))))
