"""AES-GCM sealing and opening of vault session tickets.

Field elements are 16-byte blocks interpreted in the bit order fixed by
NIST SP 800-38D: the most significant bit of the first byte is the coefficient
of x^0, and multiplication by x is a right shift reduced by
R = 0xe1 || 0^120. This reproduces the GHASH universal hash exactly, so a ticket
produced by :func:`seal` is byte-for-byte identical to one from any conforming
AES-GCM implementation.
"""

from __future__ import annotations

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

_R = 0xE1 << 120
_MASK = (1 << 128) - 1


def mul(x: int, y: int) -> int:
    z = 0
    v = y
    for i in range(127, -1, -1):
        if (x >> i) & 1:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ _R
        else:
            v >>= 1
    return z


def block_to_int(block: bytes) -> int:
    return int.from_bytes(block, "big")


def int_to_block(value: int) -> bytes:
    return (value & _MASK).to_bytes(16, "big")


def ghash(h: int, aad: bytes, ciphertext: bytes) -> int:
    acc = 0
    for data in (aad, ciphertext):
        for off in range(0, len(data), 16):
            chunk = data[off : off + 16]
            if len(chunk) < 16:
                chunk = chunk + b"\x00" * (16 - len(chunk))
            acc = mul(acc ^ block_to_int(chunk), h)
    length_block = (len(aad) * 8).to_bytes(8, "big") + (len(ciphertext) * 8).to_bytes(8, "big")
    return mul(acc ^ block_to_int(length_block), h)


def _aes_ecb(key: bytes, block: bytes) -> bytes:
    enc = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
    return enc.update(block) + enc.finalize()


def _inc32(block: bytes) -> bytes:
    prefix, ctr = block[:12], int.from_bytes(block[12:], "big")
    return prefix + ((ctr + 1) & 0xFFFFFFFF).to_bytes(4, "big")


def _keystream(key: bytes, j0: bytes, nbytes: int) -> bytes:
    out = bytearray()
    ctr = _inc32(j0)
    while len(out) < nbytes:
        out += _aes_ecb(key, ctr)
        ctr = _inc32(ctr)
    return bytes(out[:nbytes])


def hash_subkey(key: bytes) -> int:
    return block_to_int(_aes_ecb(key, b"\x00" * 16))


def tag_for(key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes = b"") -> bytes:
    j0 = nonce + b"\x00\x00\x00\x01"
    s = ghash(hash_subkey(key), aad, ciphertext)
    return int_to_block(s ^ block_to_int(_aes_ecb(key, j0)))


def seal(key: bytes, nonce: bytes, plaintext: bytes, aad: bytes = b"") -> tuple[bytes, bytes]:
    j0 = nonce + b"\x00\x00\x00\x01"
    ks = _keystream(key, j0, len(plaintext))
    ciphertext = bytes(p ^ k for p, k in zip(plaintext, ks))
    return ciphertext, tag_for(key, nonce, ciphertext, aad)


def open_ticket(key: bytes, nonce: bytes, ciphertext: bytes, tag: bytes, aad: bytes = b"") -> bytes | None:
    import hmac

    if not hmac.compare_digest(tag_for(key, nonce, ciphertext, aad), tag):
        return None
    j0 = nonce + b"\x00\x00\x00\x01"
    ks = _keystream(key, j0, len(ciphertext))
    return bytes(c ^ k for c, k in zip(ciphertext, ks))
