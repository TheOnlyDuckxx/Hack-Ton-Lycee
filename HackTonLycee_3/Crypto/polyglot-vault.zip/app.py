"""Polyglot Vault: a password-locked secrets vault.

The vault is sealed under the owner's master passphrase. A session ticket is an
AES-GCM blob; presenting a ticket that opens under the vault key resumes the
owner session. Recover the owner passphrase and submit it to /unlock for the
flag.
"""

from __future__ import annotations

import binascii
import hmac
import os
import secrets

from argon2.low_level import Type, hash_secret_raw
from flask import Flask, jsonify, request

import gf128

FLAG_PATH = "/srv/flag.txt"

KDF_TIME = 2
KDF_MEMORY = 512
KDF_PARALLELISM = 1
KDF_HASH_LEN = 16

NONCE_LEN = 12
TAG_LEN = 16

TICKET_DOMAIN = b"polyglot-vault/ticket/v1"

LOGIN_BUDGET = 200


def _load_flag() -> str:
    try:
        with open(FLAG_PATH, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except FileNotFoundError:
        return "HTL{dev_default_polyglotvault}"


def _load_words() -> list[str]:
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "wordlist.txt"), "r", encoding="utf-8") as fh:
        return [w.strip() for w in fh if w.strip()]


def kdf(password: str) -> bytes:
    return hash_secret_raw(
        password.encode("utf-8"),
        SALT,
        time_cost=KDF_TIME,
        memory_cost=KDF_MEMORY,
        parallelism=KDF_PARALLELISM,
        hash_len=KDF_HASH_LEN,
        type=Type.ID,
    )


FLAG = _load_flag()
WORDS = _load_words()
CANDIDATES = [f"{a}-{b}" for a in WORDS for b in WORDS]
SALT = secrets.token_bytes(16)
OWNER_PASSPHRASE = secrets.choice(CANDIDATES)
VAULT_KEY = kdf(OWNER_PASSPHRASE)

_state = {"budget": LOGIN_BUDGET}

app = Flask(__name__)


INDEX = """<!doctype html>
<title>Polyglot Vault</title>
<h1>Polyglot Vault</h1>
<p>A secrets vault sealed under the owner's master passphrase.</p>
<p>A <em>session ticket</em> is an AES-128-GCM blob
<code>nonce(12) || ciphertext || tag(16)</code>, hex-encoded. Presenting a
ticket that opens under the vault key resumes the owner's session. The vault
accepts a ticket iff its authentication tag verifies.</p>
<ul>
  <li><code>GET  /params</code> &mdash; salt, KDF parameters, ticket format, passphrase grammar</li>
  <li><code>POST /login</code> &mdash; <code>{"ticket_hex": "..."}</code> (optional <code>password</code> to resume a named account) &rarr; accepted/rejected</li>
  <li><code>POST /unlock</code> &mdash; <code>{"password": "..."}</code> &rarr; the flag if it is the owner passphrase</li>
</ul>
<p>A well-formed ticket plaintext is the length-prefixed, domain-tagged record
<code>field(%r) || field(account) || field(nonce_echo)</code> where
<code>field(x) = len(x):2 || x</code>, but the vault only checks the tag.</p>
""" % (TICKET_DOMAIN.decode(),)


@app.get("/")
def index():
    return INDEX


@app.get("/healthz")
def healthz():
    return jsonify(status="ok")


@app.get("/params")
def params():
    return jsonify(
        cipher="AES-128-GCM",
        nonce_len=NONCE_LEN,
        tag_len=TAG_LEN,
        salt=SALT.hex(),
        kdf={
            "name": "argon2id",
            "time_cost": KDF_TIME,
            "memory_cost": KDF_MEMORY,
            "parallelism": KDF_PARALLELISM,
            "hash_len": KDF_HASH_LEN,
        },
        ticket_format="hex(nonce(12) || ciphertext || tag(16))",
        ticket_domain=TICKET_DOMAIN.decode(),
        grammar={
            "format": "<word>-<word>",
            "words": WORDS,
            "count": len(CANDIDATES),
        },
        login="POST ticket_hex; the vault opens it under the owner key and reports accepted iff the tag verifies.",
    )


@app.post("/login")
def login():
    if _state["budget"] <= 0:
        return jsonify(error="login budget exhausted for this instance"), 429
    _state["budget"] -= 1

    data = request.get_json(silent=True) or {}
    ticket_hex = data.get("ticket_hex")
    if not isinstance(ticket_hex, str):
        return jsonify(error="expected ticket_hex"), 400
    try:
        raw = binascii.unhexlify(ticket_hex.strip())
    except (binascii.Error, ValueError):
        return jsonify(error="ticket_hex is not valid hex"), 400
    if len(raw) < NONCE_LEN + TAG_LEN:
        return jsonify(error="ticket too short"), 400

    nonce = raw[:NONCE_LEN]
    tag = raw[-TAG_LEN:]
    ciphertext = raw[NONCE_LEN:-TAG_LEN]

    password = data.get("password")
    if isinstance(password, str) and password:
        key = kdf(password)
    else:
        key = VAULT_KEY

    opened = gf128.open_ticket(key, nonce, ciphertext, tag)
    if opened is None:
        return jsonify(status="rejected", budget=_state["budget"])
    return jsonify(status="accepted", budget=_state["budget"])


@app.post("/unlock")
def unlock():
    data = request.get_json(silent=True) or {}
    password = data.get("password")
    if not isinstance(password, str):
        return jsonify(error="expected password"), 400
    if hmac.compare_digest(password.encode("utf-8"), OWNER_PASSPHRASE.encode("utf-8")):
        return jsonify(flag=FLAG)
    return jsonify(error="not the owner passphrase"), 403


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9003)
