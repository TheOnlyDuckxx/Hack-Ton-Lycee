"""Orphic Seal: an anonymous-credential issuer.

Enrol by proving knowledge of the discrete log of one of the published issuer
keys with a non-interactive OR-proof; a successful proof mints an anonymous
credential. Present an admin credential to /mint to receive the flag.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from typing import List

from flask import Flask, jsonify, request

from group import G, P, Q, exp
from orproof import (
    DOMAIN_ENROLL,
    DOMAIN_REVOKE,
    enroll_challenge,
    revoke_challenge,
    verify,
)

N = 8

FLAG_PATH = "/srv/flag.txt"


def _load_flag() -> str:
    try:
        with open(FLAG_PATH, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except FileNotFoundError:
        return "HTL{dev_default_orphic}"


FLAG = _load_flag()
CRED_KEY = secrets.token_bytes(32)

_ISSUER_SECRETS = [secrets.randbelow(Q - 1) + 1 for _ in range(N)]
ISSUER_KEYS: List[int] = [exp(G, x) for x in _ISSUER_SECRETS]

app = Flask(__name__)


def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _b64d(txt: str) -> bytes:
    pad = "=" * (-len(txt) % 4)
    return base64.urlsafe_b64decode(txt + pad)


def issue_credential(payload: dict) -> str:
    body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    sig = hmac.new(CRED_KEY, body, hashlib.sha256).digest()
    return _b64e(body) + "." + _b64e(sig)


def read_credential(token: str):
    try:
        body_b64, sig_b64 = token.split(".", 1)
        body = _b64d(body_b64)
        sig = _b64d(sig_b64)
    except Exception:
        return None
    expected = hmac.new(CRED_KEY, body, hashlib.sha256).digest()
    if not hmac.compare_digest(sig, expected):
        return None
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        return None


def _parse_scalars(values) -> List[int]:
    return [int(v, 16) for v in values]


INDEX = """<!doctype html>
<title>Orphic Seal</title>
<h1>Orphic Seal</h1>
<p>An anonymous-credential issuer over a prime-order group.</p>
<p>Enrolment requires a non-interactive Schnorr OR-proof of knowledge of the
discrete logarithm of one of the published issuer public keys. The proof hides
which key you used. A valid proof mints an anonymous credential; present an
admin credential to <code>/mint</code> to receive the flag.</p>
<ul>
  <li><code>GET  /params</code> &mdash; group parameters and issuer public keys</li>
  <li><code>POST /enroll</code> &mdash; submit an OR-proof, receive a credential</li>
  <li><code>POST /revoke</code> &mdash; submit a revocation OR-proof</li>
  <li><code>POST /mint</code> &mdash; redeem an admin credential for the flag</li>
</ul>
<p>Proof wire format: JSON <code>{"c": ["&lt;hex&gt;", ...], "s": ["&lt;hex&gt;", ...]}</code>
with one entry per issuer key. The verifier recovers
<code>R_i = G^{s_i} * Y_i^{-c_i}</code>, binds a domain-separated transcript over
the statement and commitments, and accepts iff
<code>sum_i c_i == H(transcript) mod Q</code>.</p>
"""


@app.get("/")
def index():
    return INDEX


@app.get("/healthz")
def healthz():
    return jsonify(status="ok")


@app.get("/params")
def params():
    return jsonify(
        group="QR subgroup of RFC3526 2048-bit MODP safe prime",
        p=format(P, "x"),
        q=format(Q, "x"),
        g=format(G, "x"),
        n=N,
        domain_enroll=DOMAIN_ENROLL.decode(),
        domain_revoke=DOMAIN_REVOKE.decode(),
        transcript="H(domain || [len||Y_i]_i || [len||R_i]_i) mod q, SHA-512",
        issuer_keys=[format(y, "x") for y in ISSUER_KEYS],
    )


@app.post("/enroll")
def enroll():
    data = request.get_json(silent=True) or {}
    try:
        c = _parse_scalars(data["c"])
        s = _parse_scalars(data["s"])
    except (KeyError, TypeError, ValueError):
        return jsonify(error="expected c[] and s[] as hex scalars"), 400
    if len(c) != N or len(s) != N:
        return jsonify(error=f"proof must carry {N} clauses"), 400
    if not verify(DOMAIN_ENROLL, ISSUER_KEYS, c, s, enroll_challenge):
        return jsonify(error="proof rejected"), 403
    credential = issue_credential({"admin": True, "sn": secrets.token_hex(8)})
    return jsonify(credential=credential)


@app.post("/revoke")
def revoke():
    data = request.get_json(silent=True) or {}
    try:
        c = _parse_scalars(data["c"])
        s = _parse_scalars(data["s"])
    except (KeyError, TypeError, ValueError):
        return jsonify(error="expected c[] and s[] as hex scalars"), 400
    if len(c) != N or len(s) != N:
        return jsonify(error=f"proof must carry {N} clauses"), 400
    if not verify(DOMAIN_REVOKE, ISSUER_KEYS, c, s, revoke_challenge):
        return jsonify(error="proof rejected"), 403
    token = issue_credential({"admin": False, "revoked": True, "sn": secrets.token_hex(8)})
    return jsonify(receipt=token)


@app.post("/mint")
def mint():
    data = request.get_json(silent=True) or {}
    token = data.get("credential")
    if not isinstance(token, str):
        return jsonify(error="expected credential string"), 400
    claims = read_credential(token)
    if claims is None:
        return jsonify(error="invalid credential"), 403
    if claims.get("admin") is not True:
        return jsonify(error="credential is not privileged"), 403
    return jsonify(flag=FLAG)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9001)
