"""Prime-order group arithmetic for the Orphic Seal credential service.

The group is the subgroup of quadratic residues modulo the RFC 3526 2048-bit
MODP safe prime ``P = 2*Q + 1``. That subgroup has prime order ``Q``, so every
non-identity element is a generator and there is no cofactor to worry about.

Group elements are integers in ``[1, P-1]``; the group operation is
multiplication modulo ``P``. Scalars live in ``Z_Q``. Elements serialise to a
fixed ``ELEMENT_BYTES``-byte big-endian encoding so the Fiat-Shamir transcript
is unambiguous.
"""

from __future__ import annotations

_P_HEX = (
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
    "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
    "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
    "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
    "83655D23DCA3AD961C62F356208552BB9ED529077096966D"
    "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9"
    "DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
    "15728E5A8AACAA68FFFFFFFFFFFFFFFF"
)

P = int(_P_HEX, 16)
Q = (P - 1) // 2
G = 2

ELEMENT_BYTES = (P.bit_length() + 7) // 8
SCALAR_BYTES = (Q.bit_length() + 7) // 8


def mul(a: int, b: int) -> int:
    """Group operation: multiply two elements."""
    return (a * b) % P


def inv(a: int) -> int:
    """Inverse of a group element."""
    return pow(a, P - 2, P)


def exp(base: int, scalar: int) -> int:
    """Scalar multiplication (written multiplicatively as exponentiation)."""
    return pow(base, scalar % Q, P)


def encode(element: int) -> bytes:
    """Canonical fixed-length big-endian encoding of a group element."""
    return (element % P).to_bytes(ELEMENT_BYTES, "big")


def scalar_from_hash(digest: bytes) -> int:
    """Reduce a hash digest to a scalar in Z_Q."""
    return int.from_bytes(digest, "big") % Q
