"""Non-interactive Schnorr OR-proofs over the prime-order group.

A proof demonstrates knowledge of the discrete logarithm of at least one of the
published issuer public keys ``Y_1 .. Y_N`` without revealing which one. It is
the classic Cramer-Damgard-Schoenmakers OR-composition made non-interactive
with Fiat-Shamir.

A proof is transmitted as two equal-length lists of scalars, ``c`` and ``s``.
The verifier recovers each commitment as ``R_i = G^{s_i} * Y_i^{-c_i}``, binds a
domain-separated transcript over the statement and the commitments, and accepts
iff the per-clause challenges sum to the transcript challenge::

    sum_i c_i  ==  H(transcript)   (mod Q)

Two transcript bindings are provided. ``enroll_challenge`` is used by the
enrolment flow; ``revoke_challenge`` is used by the revocation flow.
"""

from __future__ import annotations

import hashlib
import secrets
from typing import List

from group import G, Q, encode, exp, inv, mul, scalar_from_hash

DOMAIN_ENROLL = b"ORPHIC-OR-v1"
DOMAIN_REVOKE = b"ORPHIC-REVOKE-v1"


def _field(blob: bytes) -> bytes:
    return len(blob).to_bytes(4, "big") + blob


def enroll_challenge(domain: bytes, ys: List[int], rs: List[int]) -> int:
    n = len(ys)
    h = hashlib.sha512()
    h.update(domain)
    for i in range(n):
        h.update(_field(encode(ys[i])))
    for i in range(n - 1):
        h.update(_field(encode(rs[i])))
    return scalar_from_hash(h.digest())


def revoke_challenge(domain: bytes, ys: List[int], rs: List[int]) -> int:
    n = len(ys)
    h = hashlib.sha512()
    h.update(domain)
    for i in range(n):
        h.update(_field(encode(ys[i])))
    for i in range(n):
        h.update(_field(encode(rs[i])))
    return scalar_from_hash(h.digest())


def recover_commitments(ys: List[int], c: List[int], s: List[int]) -> List[int]:
    return [mul(exp(G, s[i]), inv(exp(ys[i], c[i]))) for i in range(len(ys))]


def verify(domain: bytes, ys: List[int], c: List[int], s: List[int], challenge_fn) -> bool:
    n = len(ys)
    if len(c) != n or len(s) != n:
        return False
    rs = recover_commitments(ys, c, s)
    expected = challenge_fn(domain, ys, rs)
    return (sum(ci % Q for ci in c) % Q) == expected


def prove(domain: bytes, ys: List[int], witness_index: int, x: int, challenge_fn):
    """Honest prover: produce a proof using the witness for one clause."""
    n = len(ys)
    c = [0] * n
    s = [0] * n
    r = [0] * n
    for i in range(n):
        if i == witness_index:
            continue
        c[i] = secrets.randbelow(Q)
        s[i] = secrets.randbelow(Q)
        r[i] = mul(exp(G, s[i]), inv(exp(ys[i], c[i])))
    k = secrets.randbelow(Q)
    r[witness_index] = exp(G, k)
    expected = challenge_fn(domain, ys, r)
    rest = sum(c[i] for i in range(n) if i != witness_index) % Q
    c[witness_index] = (expected - rest) % Q
    s[witness_index] = (k + c[witness_index] * x) % Q
    return c, s
