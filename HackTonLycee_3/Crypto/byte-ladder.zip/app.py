import os

from flask import Flask, jsonify, render_template_string, request

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

BLOCK = 16


def load_secret():
    try:
        with open("/srv/flag.txt", "r", encoding="utf-8") as fh:
            return fh.read().strip().encode()
    except FileNotFoundError:
        return b"HTL{dev_default_byteladder}"


SECRET = load_secret()
KEY = os.urandom(32)

app = Flask(__name__)


def pkcs7(data):
    pad = BLOCK - (len(data) % BLOCK)
    return data + bytes([pad]) * pad


def encrypt(data):
    cipher = Cipher(algorithms.AES(KEY), modes.ECB())
    enc = cipher.encryptor()
    return enc.update(pkcs7(data)) + enc.finalize()


def parse_input(raw):
    raw = raw.strip()
    try:
        return bytes.fromhex(raw)
    except ValueError:
        return raw.encode()


INDEX = """<!doctype html>
<title>byte-ladder</title>
<h1>byte-ladder encryption oracle</h1>
<p>The oracle appends a fixed secret to whatever you send and encrypts the
result under a per-process AES key in ECB mode.</p>
<pre>
POST /enc
  form field or JSON field: data
  data is interpreted as hex if it is valid hex, otherwise as raw text

  response: {"ct": "&lt;hex of AES-ECB(data || secret)&gt;"}
</pre>
<p>Example:</p>
<pre>curl -s -X POST {{ url }}/enc -d 'data=4141'</pre>
"""


@app.get("/")
def index():
    return render_template_string(INDEX, url=request.host_url.rstrip("/"))


@app.post("/enc")
def enc():
    if request.is_json:
        payload = request.get_json(silent=True) or {}
        raw = payload.get("data", "")
    else:
        raw = request.form.get("data", "")
    data = parse_input(raw)
    ct = encrypt(data + SECRET)
    return jsonify({"ct": ct.hex()})


@app.get("/healthz")
def healthz():
    return "ok", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9005)
