# Seam Split

A key-management appliance provisions RSA keypairs for a fleet of services and
publishes their moduli. One of them encrypts the flag.

`keys.json` contains:

- `e` - the public exponent, `65537`;
- `moduli` - the published moduli `N_0 .. N_7`, hex;
- `flag_index` - which modulus encrypts the flag;
- `flag_ciphertext` - `m^e mod N_{flag_index}` where `m` is the flag bytes, hex.

## The verifier

The service holds no private keys. Once you can produce a non-trivial factor of
the designated modulus, submit it and the service will finish the decryption:

```
POST /factor
{"p": "<hex factor of N_{flag_index}>"}
```

A correct factor returns the flag. Also available: `GET /` and `GET /keys.json`.

The flag has the form `HTL{...}`.
