"""QuickBoard — a minimal kanban service with cookie-based sessions."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import pathlib

from flask import Flask, make_response, render_template, request

FLAG_PATH = pathlib.Path("/srv/flag.txt")
FALLBACK_FLAG = "HTL{dev_default_tokengate}"

SECRET = os.environ.get("QUICKBOARD_SECRET", "s3rv3r-side-signing-key").encode()
COOKIE_NAME = "qb_session"


def load_flag() -> str:
    try:
        return FLAG_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return FALLBACK_FLAG


FLAG = load_flag()

app = Flask(__name__)


def b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def issue_token(claims: dict) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    header_b64 = b64url_encode(json.dumps(header, separators=(",", ":")).encode())
    payload_b64 = b64url_encode(json.dumps(claims, separators=(",", ":")).encode())
    signing_input = f"{header_b64}.{payload_b64}".encode()
    signature = hmac.new(SECRET, signing_input, hashlib.sha256).digest()
    return f"{header_b64}.{payload_b64}.{b64url_encode(signature)}"


def verify_token(token: str) -> dict | None:
    parts = token.split(".")
    if len(parts) != 3:
        return None

    header_b64, payload_b64, signature_b64 = parts
    try:
        header = json.loads(b64url_decode(header_b64))
        payload = json.loads(b64url_decode(payload_b64))
    except (ValueError, json.JSONDecodeError):
        return None

    alg = header.get("alg")
    if alg == "none":
        return payload

    if alg == "HS256":
        signing_input = f"{header_b64}.{payload_b64}".encode()
        expected = hmac.new(SECRET, signing_input, hashlib.sha256).digest()
        try:
            provided = b64url_decode(signature_b64)
        except ValueError:
            return None
        if hmac.compare_digest(expected, provided):
            return payload
        return None

    return None


def current_claims():
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
    return verify_token(token)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/login")
def login():
    username = (request.form.get("username") or "").strip()
    password = request.form.get("password") or ""
    if not username or not password:
        return render_template("index.html", error="Username and password required."), 400

    token = issue_token({"sub": username, "role": "user"})
    resp = make_response(render_template("board.html", username=username, role="user"))
    resp.set_cookie(COOKIE_NAME, token, httponly=True, samesite="Lax")
    return resp


@app.get("/board")
def board():
    claims = current_claims()
    if not claims:
        return render_template("index.html", error="Please sign in first."), 401
    return render_template(
        "board.html",
        username=claims.get("sub", "unknown"),
        role=claims.get("role", "user"),
    )


@app.get("/admin/board")
def admin_board():
    claims = current_claims()
    if not claims:
        return render_template("index.html", error="Please sign in first."), 401
    if claims.get("role") != "admin":
        return render_template("denied.html"), 403
    return render_template("admin.html", flag=FLAG)


@app.get("/healthz")
def healthz():
    return {"status": "ok"}, 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8005)
