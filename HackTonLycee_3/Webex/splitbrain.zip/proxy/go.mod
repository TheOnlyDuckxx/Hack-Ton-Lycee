module streamfront

go 1.22
