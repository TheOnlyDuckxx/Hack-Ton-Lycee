package main

import (
	"bufio"
	"bytes"
	"errors"
	"io"
	"net"
	"net/textproto"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	adminHost = "admin.internal"
	// Clients bind to an isolated worker + its console keep-alive by sending a
	// stable session id on every request (canonicalised header key). Keying on
	// this, not the source IP, keeps clients behind the same NAT isolated.
	sessionHeader = "X-Streamfront-Session"
	maxSessions   = 4096
)

var (
	backendAddr = env("BACKEND_ADDR", "backend:9000")
	edgeAddr    = env("EDGE_ADDR", ":8001")
	adminUser   = env("ADMIN_USER", "ops-admin")
	adminPass   = env("ADMIN_PASS", "dev-console-"+"000000000000")
)

// How long a client's upstream (and its console keep-alive) survives with no
// further traffic from that client, after which it is torn down and re-created
// fresh on the next request.
const sessionTTL = 180 * time.Second

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

type upstream struct {
	mu   sync.Mutex
	conn net.Conn
	r    *bufio.Reader
}

func (u *upstream) dial() error {
	c, err := net.Dial("tcp", backendAddr)
	if err != nil {
		return err
	}
	if tc, ok := c.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
	}
	u.conn = c
	u.r = bufio.NewReader(c)
	return nil
}

func (u *upstream) roundtrip(raw []byte) ([]byte, error) {
	u.mu.Lock()
	defer u.mu.Unlock()
	for attempt := 0; attempt < 2; attempt++ {
		if u.conn == nil {
			if err := u.dial(); err != nil {
				return nil, err
			}
		}
		if _, err := u.conn.Write(raw); err != nil {
			u.reset()
			continue
		}
		resp, err := readResponse(u.r)
		if err != nil {
			u.reset()
			continue
		}
		return resp, nil
	}
	return nil, errors.New("upstream unavailable")
}

func (u *upstream) reset() {
	if u.conn != nil {
		_ = u.conn.Close()
	}
	u.conn = nil
	u.r = nil
}

// Per-client session. Each client (keyed by source address) gets its own
// upstream connection to the origin and its own console keep-alive running on
// that connection. A client can only ever desync and read responses off its
// OWN upstream, so one client's traffic can never surface on another's.
type session struct {
	up       *upstream
	lastSeen time.Time
}

var (
	sessMu   sync.Mutex
	sessions = map[string]*session{}
)

func getSession(key string, withAdmin bool) *session {
	sessMu.Lock()
	defer sessMu.Unlock()
	if s := sessions[key]; s != nil {
		s.lastSeen = time.Now()
		return s
	}
	if len(sessions) >= maxSessions {
		// Bounded under churn: hand out one shared overflow worker with no
		// console agent rather than spawning unbounded sessions.
		key, withAdmin = "overflow", false
		if s := sessions[key]; s != nil {
			s.lastSeen = time.Now()
			return s
		}
	}
	s := &session{up: &upstream{}}
	sessions[key] = s
	if withAdmin {
		go adminKeepAlive(key, s)
	}
	s.lastSeen = time.Now()
	return s
}

// adminKeepAlive logs the operations console in on a tight loop over THIS
// session's upstream, exactly as the real ops agent would, so the desync
// target exists per-session rather than on one shared socket. It exits when
// the session is reaped.
func adminKeepAlive(key string, s *session) {
	body := []byte("user=" + adminUser + "&pass=" + adminPass)
	req := []byte("POST /admin/login HTTP/1.1\r\n" +
		"Host: " + adminHost + "\r\n" +
		"Content-Type: application/x-www-form-urlencoded\r\n" +
		"Content-Length: " + strconv.Itoa(len(body)) + "\r\n" +
		"Connection: keep-alive\r\n" +
		"\r\n")
	req = append(req, body...)
	for {
		sessMu.Lock()
		current := sessions[key] == s
		sessMu.Unlock()
		if !current {
			s.up.reset()
			return
		}
		_, _ = s.up.roundtrip(req)
		time.Sleep(400 * time.Millisecond)
	}
}

func janitor() {
	for {
		time.Sleep(30 * time.Second)
		now := time.Now()
		sessMu.Lock()
		for key, s := range sessions {
			if now.Sub(s.lastSeen) > sessionTTL {
				delete(sessions, key)
			}
		}
		sessMu.Unlock()
	}
}

type request struct {
	raw       []byte
	headers   map[string]string
	host      string
	malformed bool
	expect    string
}

func readRequest(r *bufio.Reader) (*request, error) {
	var raw bytes.Buffer
	req := &request{headers: map[string]string{}}

	first, err := readLine(r, &raw)
	if err != nil {
		return nil, err
	}
	if strings.TrimSpace(first) == "" {
		return nil, errors.New("empty request line")
	}

	for {
		line, err := readLine(r, &raw)
		if err != nil {
			return nil, err
		}
		if line == "" {
			break
		}
		idx := strings.IndexByte(line, ':')
		if idx < 0 {
			continue
		}
		name := line[:idx]
		value := strings.TrimSpace(line[idx+1:])
		if name != strings.TrimSpace(name) {
			req.malformed = true
		}
		req.headers[textproto.CanonicalMIMEHeaderKey(name)] = value
		// Resolve the routing host the way a lenient origin would, from any
		// line whose trimmed name is "host" -- including an obfuscated
		// "Host :" that would not survive header canonicalisation -- so the
		// console vhost can never be reached directly off the public edge.
		if strings.EqualFold(strings.TrimSpace(name), "host") {
			h := strings.ToLower(strings.SplitN(value, ":", 2)[0])
			if h == adminHost {
				req.host = adminHost
			} else if req.host == "" {
				req.host = h
			}
		}
	}
	req.expect = strings.ToLower(strings.TrimSpace(hdr(req.headers, "Expect")))

	body, err := readBody(r, req, &raw)
	if err != nil {
		return nil, err
	}
	_ = body
	req.raw = append([]byte(nil), raw.Bytes()...)
	return req, nil
}

func readBody(r *bufio.Reader, req *request, raw *bytes.Buffer) ([]byte, error) {
	te := strings.ToLower(strings.TrimSpace(hdr(req.headers, "Transfer-Encoding")))
	cl := hdr(req.headers, "Content-Length")

	if req.expect != "100-continue" {
		if req.malformed {
			return nil, errBadRequest
		}
		if te != "" && cl != "" {
			return nil, errBadRequest
		}
	}

	if te == "chunked" {
		return copyChunked(r, raw)
	}
	if cl != "" {
		n, err := strconv.Atoi(cl)
		if err != nil || n < 0 {
			return nil, errBadRequest
		}
		buf := make([]byte, n)
		if _, err := io.ReadFull(r, buf); err != nil {
			return nil, err
		}
		raw.Write(buf)
		return buf, nil
	}
	return nil, nil
}

var errBadRequest = errors.New("bad request")

func copyChunked(r *bufio.Reader, raw *bytes.Buffer) ([]byte, error) {
	var body bytes.Buffer
	for {
		line, err := readLine(r, raw)
		if err != nil {
			return nil, err
		}
		size, err := strconv.ParseInt(strings.SplitN(strings.TrimSpace(line), ";", 2)[0], 16, 64)
		if err != nil {
			return nil, errBadRequest
		}
		if size == 0 {
			for {
				t, err := readLine(r, raw)
				if err != nil {
					return nil, err
				}
				if t == "" {
					return body.Bytes(), nil
				}
			}
		}
		buf := make([]byte, size)
		if _, err := io.ReadFull(r, buf); err != nil {
			return nil, err
		}
		raw.Write(buf)
		body.Write(buf)
		crlf := make([]byte, 2)
		if _, err := io.ReadFull(r, crlf); err != nil {
			return nil, err
		}
		raw.Write(crlf)
	}
}

func readLine(r *bufio.Reader, raw *bytes.Buffer) (string, error) {
	line, err := r.ReadBytes('\n')
	if err != nil {
		return "", err
	}
	if raw != nil {
		raw.Write(line)
	}
	return strings.TrimRight(string(line), "\r\n"), nil
}

func readResponse(r *bufio.Reader) ([]byte, error) {
	for {
		var raw bytes.Buffer
		status, err := readLine(r, &raw)
		if err != nil {
			return nil, err
		}
		headers := map[string]string{}
		for {
			line, err := readLine(r, &raw)
			if err != nil {
				return nil, err
			}
			if line == "" {
				break
			}
			idx := strings.IndexByte(line, ':')
			if idx < 0 {
				continue
			}
			headers[textproto.CanonicalMIMEHeaderKey(line[:idx])] = strings.TrimSpace(line[idx+1:])
		}
		if code := statusCode(status); code >= 100 && code < 200 {
			continue
		}
		te := strings.ToLower(strings.TrimSpace(headers["Transfer-Encoding"]))
		if te == "chunked" {
			if _, err := copyChunked(r, &raw); err != nil {
				return nil, err
			}
			return raw.Bytes(), nil
		}
		if cl := headers["Content-Length"]; cl != "" {
			n, err := strconv.Atoi(cl)
			if err != nil {
				return nil, err
			}
			buf := make([]byte, n)
			if _, err := io.ReadFull(r, buf); err != nil {
				return nil, err
			}
			raw.Write(buf)
			return raw.Bytes(), nil
		}
		return raw.Bytes(), nil
	}
}

func statusCode(line string) int {
	parts := strings.SplitN(line, " ", 3)
	if len(parts) < 2 {
		return 0
	}
	n, _ := strconv.Atoi(parts[1])
	return n
}

func hdr(h map[string]string, key string) string {
	return h[key]
}

func sessionKey(conn net.Conn) string {
	host, _, err := net.SplitHostPort(conn.RemoteAddr().String())
	if err != nil {
		return conn.RemoteAddr().String()
	}
	return host
}

func handle(conn net.Conn) {
	defer conn.Close()
	if tc, ok := conn.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
	}
	r := bufio.NewReader(conn)

	req, err := readRequest(r)
	if err != nil {
		writeSimple(conn, "400 Bad Request", "edge rejected request\n")
		return
	}

	if req.host == adminHost {
		writeSimple(conn, "403 Forbidden", "operations console is not routable from the edge\n")
		return
	}

	// A client that presents a session id gets its own isolated worker (and its
	// own console keep-alive); otherwise it shares a per-source worker with no
	// console agent, enough to browse the public site.
	var sess *session
	if token := hdr(req.headers, sessionHeader); token != "" {
		sess = getSession("tok:"+token, true)
	} else {
		sess = getSession("ip:"+sessionKey(conn), false)
	}
	resp, err := sess.up.roundtrip(req.raw)
	if err != nil {
		writeSimple(conn, "502 Bad Gateway", "origin unavailable\n")
		return
	}
	_, _ = conn.Write(resp)
}

func writeSimple(conn net.Conn, status, body string) {
	out := "HTTP/1.1 " + status + "\r\n" +
		"Content-Type: text/plain; charset=utf-8\r\n" +
		"Content-Length: " + strconv.Itoa(len(body)) + "\r\n" +
		"Connection: close\r\n\r\n" + body
	_, _ = conn.Write([]byte(out))
}

func listen(addr string) {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		panic(err)
	}
	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go handle(conn)
	}
}

func main() {
	go janitor()
	listen(edgeAddr)
}
