#!/usr/bin/env python3
"""Origin application for the StreamFront edge.

Serves two virtual hosts off one HTTP/1.1 listener:
  * the public marketing site
  * the operations console (reachable only from inside the mesh)

The server speaks HTTP/1.1 directly over the socket so the console can keep
long-lived keep-alive connections with the edge without a framework in the way.
"""
import os
import secrets
import socket
import threading
import urllib.parse

HOST = "0.0.0.0"
PORT = 9000

PUBLIC_HOST = "front.local"
CONSOLE_HOST = "admin.internal"


def _read_file(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except FileNotFoundError:
        return fallback


FLAG = _read_file("/srv/flag.txt", "HTL{dev_default_splitbrain}")
ADMIN_USER = "ops-admin"
ADMIN_PASS = _read_file("/srv/admin_pass.txt", "dev-console-" + "0" * 12)
SESSION_TOKEN = secrets.token_hex(16)


class Closed(Exception):
    pass


class Stream:
    def __init__(self, conn):
        self.conn = conn
        self.buf = b""

    def _fill(self):
        chunk = self.conn.recv(65536)
        if not chunk:
            raise Closed()
        self.buf += chunk

    def read_line(self):
        while b"\r\n" not in self.buf:
            self._fill()
        line, self.buf = self.buf.split(b"\r\n", 1)
        return line

    def read_exact(self, n):
        while len(self.buf) < n:
            self._fill()
        data, self.buf = self.buf[:n], self.buf[n:]
        return data


def parse_headers(stream):
    request_line = stream.read_line().decode("latin-1")
    headers = {}
    while True:
        line = stream.read_line().decode("latin-1")
        if line == "":
            break
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        headers[name.strip().lower()] = value.strip()
    return request_line, headers


def read_chunked(stream):
    body = b""
    while True:
        size_line = stream.read_line().decode("latin-1").strip()
        size = int(size_line.split(";", 1)[0], 16)
        if size == 0:
            while True:
                trailer = stream.read_line()
                if trailer == b"":
                    break
            return body
        body += stream.read_exact(size)
        stream.read_exact(2)


def read_body(stream, headers):
    te = headers.get("transfer-encoding")
    cl = headers.get("content-length")
    if te is not None:
        if te.lower() == "chunked":
            return read_chunked(stream)
        return b""
    if cl is not None:
        return stream.read_exact(int(cl))
    return b""


def http_response(status, body, extra=None):
    if isinstance(body, str):
        body = body.encode("utf-8")
    lines = [f"HTTP/1.1 {status}"]
    lines.append("Content-Type: text/plain; charset=utf-8")
    lines.append(f"Content-Length: {len(body)}")
    lines.append("Connection: keep-alive")
    for k, v in (extra or {}).items():
        lines.append(f"{k}: {v}")
    head = ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1")
    return head + body


def cookies_of(headers):
    jar = {}
    raw = headers.get("cookie", "")
    for part in raw.split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            jar[k.strip()] = v.strip()
    return jar


def handle_public(request_line, headers, body):
    try:
        method, path, _ = request_line.split(" ", 2)
    except ValueError:
        return http_response("400 Bad Request", "bad request\n")
    if path == "/health" or path.startswith("/health?"):
        return http_response("200 OK", "ok\n")
    if path == "/":
        return http_response(
            "200 OK",
            "StreamFront edge is up.\n"
            "The operations console runs on a separate virtual host and is not "
            "routable from the public edge.\n",
        )
    return http_response("404 Not Found", "no such resource\n")


def handle_console(request_line, headers, body):
    try:
        method, path, _ = request_line.split(" ", 2)
    except ValueError:
        return http_response("400 Bad Request", "bad request\n")

    if path == "/admin/login" and method == "POST":
        form = urllib.parse.parse_qs(body.decode("latin-1"))
        user = (form.get("user") or [""])[0]
        password = (form.get("pass") or [""])[0]
        if user == ADMIN_USER and password == ADMIN_PASS:
            return http_response(
                "200 OK",
                "console session established\n",
                {"Set-Cookie": f"adminsession={SESSION_TOKEN}; HttpOnly; Path=/"},
            )
        return http_response("401 Unauthorized", "bad console credentials\n")

    if path == "/internal/admin/export":
        jar = cookies_of(headers)
        if jar.get("adminsession") == SESSION_TOKEN:
            return http_response(
                "200 OK",
                "operations export\n"
                f"flag={FLAG}\n",
            )
        return http_response("403 Forbidden", "console session required\n")

    return http_response("404 Not Found", "no such console resource\n")


def route(request_line, headers, body):
    host = headers.get("host", "").split(":", 1)[0].strip().lower()
    expect = headers.get("expect", "").strip().lower()
    if host == CONSOLE_HOST:
        return handle_console(request_line, headers, body)
    return handle_public(request_line, headers, body)


def serve_connection(conn):
    stream = Stream(conn)
    try:
        while True:
            request_line, headers = parse_headers(stream)
            if headers.get("expect", "").strip().lower() == "100-continue":
                conn.sendall(b"HTTP/1.1 100 Continue\r\n\r\n")
            body = read_body(stream, headers)
            conn.sendall(route(request_line, headers, body))
    except Closed:
        pass
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except OSError:
            pass


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(64)
    print(f"origin listening on {HOST}:{PORT}", flush=True)
    while True:
        conn, _ = srv.accept()
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        threading.Thread(target=serve_connection, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
