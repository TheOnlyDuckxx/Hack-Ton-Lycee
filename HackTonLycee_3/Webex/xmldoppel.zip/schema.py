"""GraphQL schema, resolvers and request authorization for FleetDesk."""
from __future__ import annotations

from graphql import (
    FieldNode,
    FragmentDefinitionNode,
    FragmentSpreadNode,
    InlineFragmentNode,
    OperationDefinitionNode,
    build_schema,
    parse,
)

SDL = """
type Device {
  id: ID!
  hostname: String!
  status: String!
  lastSeen: String!
}

type Viewer {
  nameid: String!
  role: String!
}

type Query {
  viewer: Viewer!
  devices: [Device!]!
  fleetSecret: String
}
"""

schema = build_schema(SDL)

RESERVED_OPERATION = "AdminQuery"
RESTRICTED_FIELDS = {"fleetSecret"}

_DEVICES = [
    {"id": "d-1001", "hostname": "kiosk-lobby-01", "status": "online", "lastSeen": "2026-10-11T09:02:11Z"},
    {"id": "d-1002", "hostname": "kiosk-lobby-02", "status": "degraded", "lastSeen": "2026-10-11T08:47:55Z"},
    {"id": "d-1003", "hostname": "pos-register-07", "status": "online", "lastSeen": "2026-10-11T09:03:40Z"},
    {"id": "d-1004", "hostname": "signage-west-wing", "status": "offline", "lastSeen": "2026-10-10T22:19:03Z"},
]


def resolve_viewer(_root, info):
    ctx = info.context
    return {"nameid": ctx.get("nameid", ""), "role": ctx.get("role", "support")}


def resolve_devices(_root, _info):
    return _DEVICES


def resolve_fleet_secret(_root, info):
    if info.context.get("role") != "admin":
        return None
    return info.context.get("flag")


schema.query_type.fields["viewer"].resolve = resolve_viewer
schema.query_type.fields["devices"].resolve = resolve_devices
schema.query_type.fields["fleetSecret"].resolve = resolve_fleet_secret


def _selected_operation(document, operation_name):
    operations = [d for d in document.definitions if isinstance(d, OperationDefinitionNode)]
    if operation_name:
        for op in operations:
            if op.name and op.name.value == operation_name:
                return op
    return operations[0] if operations else None


def _response_keys(selection_set, fragments, seen, keys):
    """Collect the response keys reachable from a selection set.

    Walks field selections as well as inline and named fragment spreads so a
    restricted field cannot be hidden behind a fragment. Each field contributes
    its response key (its alias if present, otherwise the field name).
    """
    if selection_set is None:
        return
    for selection in selection_set.selections:
        if isinstance(selection, FieldNode):
            key = selection.alias.value if selection.alias else selection.name.value
            keys.add(key)
            _response_keys(selection.selection_set, fragments, seen, keys)
        elif isinstance(selection, InlineFragmentNode):
            _response_keys(selection.selection_set, fragments, seen, keys)
        elif isinstance(selection, FragmentSpreadNode):
            fragment_name = selection.name.value
            if fragment_name in seen:
                continue
            seen.add(fragment_name)
            fragment = fragments.get(fragment_name)
            if fragment is not None:
                _response_keys(fragment.selection_set, fragments, seen, keys)


def authorize(query: str, operation_name: str | None) -> str | None:
    """Return an error string if the request is not permitted, else None.

    Reads on restricted fields are reserved for the internal `AdminQuery`
    operation; the public endpoint rejects that operation name and strips any
    restricted key out of the response selection.
    """
    document = parse(query)
    operation = _selected_operation(document, operation_name)
    if operation is None:
        return "no operation found in request"

    name = operation.name.value if operation.name else None
    if name == RESERVED_OPERATION:
        return "operation name 'AdminQuery' is reserved for the internal console"

    fragments = {
        d.name.value: d
        for d in document.definitions
        if isinstance(d, FragmentDefinitionNode)
    }
    response_keys: set[str] = set()
    _response_keys(operation.selection_set, fragments, set(), response_keys)

    restricted = response_keys & RESTRICTED_FIELDS
    if restricted:
        field = sorted(restricted)[0]
        return f"field '{field}' may only be requested by the AdminQuery operation"

    return None
