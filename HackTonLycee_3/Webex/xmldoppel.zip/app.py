"""FleetDesk support console: SAML-gated GraphQL API."""
from __future__ import annotations

import base64
import os
import pathlib

from flask import Flask, jsonify, render_template, request, session
from graphql import graphql_sync

import saml_verify
import schema as gql

BASE = pathlib.Path(__file__).resolve().parent
CERT = (BASE / "idp" / "idp_cert.pem").read_bytes()
SAMPLE_RESPONSE = (BASE / "idp" / "lowpriv_response.xml").read_bytes()

ADMIN_NAMEIDS = {"svc-admin"}


def _load_flag() -> str:
    try:
        return pathlib.Path("/srv/flag.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return "HTL{dev_default_xmldoppel}"


FLAG = _load_flag()

app = Flask(__name__)
app.secret_key = os.urandom(32)


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/healthz")
def healthz():
    return "ok", 200


@app.get("/params")
def params():
    return jsonify(
        issuer="https://idp.fleetdesk.test",
        acs="/saml/acs",
        certificate=CERT.decode(),
        sample_response=base64.b64encode(SAMPLE_RESPONSE).decode(),
    )


@app.post("/saml/acs")
def acs():
    raw = request.form.get("SAMLResponse")
    if not raw:
        return jsonify(error="missing SAMLResponse"), 400
    try:
        xml = base64.b64decode(raw)
    except Exception:
        return jsonify(error="SAMLResponse is not valid base64"), 400

    try:
        saml_verify.verify_signature(xml, CERT)
        identity = saml_verify.extract_identity(xml)
    except saml_verify.SamlError as exc:
        return jsonify(error=str(exc)), 403

    nameid = identity["nameid"]
    role = "admin" if nameid in ADMIN_NAMEIDS else identity["role"]
    session.clear()
    session["nameid"] = nameid
    session["role"] = role
    return jsonify(nameid=nameid, role=role)


@app.post("/graphql")
def graphql_endpoint():
    if "nameid" not in session:
        return jsonify(errors=[{"message": "authentication required"}]), 401

    payload = request.get_json(silent=True) or {}
    query = payload.get("query") or ""
    operation_name = payload.get("operationName")
    variables = payload.get("variables") or {}

    try:
        denial = gql.authorize(query, operation_name)
    except Exception as exc:  # noqa: BLE001
        return jsonify(errors=[{"message": f"could not parse query: {exc}"}]), 400
    if denial:
        return jsonify(errors=[{"message": denial}]), 403

    context = {
        "nameid": session.get("nameid"),
        "role": session.get("role"),
        "flag": FLAG,
    }
    result = graphql_sync(
        gql.schema,
        query,
        context_value=context,
        operation_name=operation_name,
        variable_values=variables,
    )

    body = {}
    if result.data is not None:
        body["data"] = result.data
    if result.errors:
        body["errors"] = [{"message": str(err)} for err in result.errors]
    return jsonify(body)
