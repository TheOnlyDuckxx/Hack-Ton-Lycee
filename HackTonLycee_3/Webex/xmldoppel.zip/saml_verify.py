"""Minimal in-house SAML 2.0 response verifier for the FleetDesk console.

The verifier performs an XML-DSIG enveloped-signature check over the signed
assertion and then pulls the subject identity out of the response. It supports
the small profile the FleetDesk IdP emits: a single RSA-SHA256 signature with
an enveloped transform and an exclusive canonicalization.
"""
from __future__ import annotations

import base64
import hashlib
import xml.etree.ElementTree as ET

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from lxml import etree

DS = "http://www.w3.org/2000/09/xmldsig#"
SAML = "urn:oasis:names:tc:SAML:2.0:assertion"


class SamlError(Exception):
    """Raised when a response cannot be trusted."""


def _canon(xml_bytes: bytes) -> bytes:
    return ET.canonicalize(xml_bytes, strip_text=False).encode()


def _node_canon(node: ET.Element) -> bytes:
    return _canon(ET.tostring(node))


def _public_key(cert_pem: bytes):
    return x509.load_pem_x509_certificate(cert_pem).public_key()


def verify_signature(xml_bytes: bytes, cert_pem: bytes) -> bool:
    """Validate the enveloped signature against the IdP certificate.

    Confirms the SignatureValue over SignedInfo and the reference digest over
    the element named by the reference URI. Raises SamlError on any failure.
    """
    pub = _public_key(cert_pem)
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        raise SamlError(f"malformed document: {exc}") from exc

    sig = root.find(f".//{{{DS}}}Signature")
    if sig is None:
        raise SamlError("no signature present")

    signed_info = sig.find(f"{{{DS}}}SignedInfo")
    sig_value = sig.find(f"{{{DS}}}SignatureValue")
    if signed_info is None or sig_value is None or not (sig_value.text or "").strip():
        raise SamlError("incomplete signature")

    try:
        pub.verify(
            base64.b64decode(sig_value.text),
            _node_canon(signed_info),
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
    except Exception as exc:  # noqa: BLE001 - any failure is a rejection
        raise SamlError("signature value rejected") from exc

    reference = signed_info.find(f"{{{DS}}}Reference")
    if reference is None:
        raise SamlError("no reference")
    ref_id = (reference.get("URI") or "").lstrip("#")
    if not ref_id:
        raise SamlError("empty reference uri")

    target = None
    for element in root.iter():
        if element.get("ID") == ref_id:
            target = element
            break
    if target is None:
        raise SamlError("reference does not resolve")

    enveloped = target.find(f"{{{DS}}}Signature")
    if enveloped is not None:
        target.remove(enveloped)

    canon = _node_canon(target)
    if not canon.strip():
        raise SamlError("canonicalization produced an empty node set")

    computed = base64.b64encode(hashlib.sha256(canon).digest()).decode()
    expected = (reference.find(f"{{{DS}}}DigestValue").text or "").strip()
    if computed != expected:
        raise SamlError("reference digest mismatch")

    return True


def extract_identity(xml_bytes: bytes) -> dict:
    """Return the subject identity carried by the response."""
    root = etree.fromstring(xml_bytes)
    name_id = root.find(f".//{{{SAML}}}NameID")
    if name_id is None:
        raise SamlError("no subject in response")

    role = root.xpath(
        "string(.//*[local-name()='Attribute'][@Name='role']"
        "/*[local-name()='AttributeValue'])"
    )
    return {"nameid": name_id.text or "", "role": role or "support"}
