"""SQLite-backed storage for clients, users, pushed requests and codes."""
from __future__ import annotations

import os
import sqlite3
import time

DB_PATH = os.environ.get("PASSGATE_DB", "/tmp/passgate.db")


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=8000")
    return conn


def init_db(admin_password: str) -> None:
    with _connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS clients (
                client_id TEXT PRIMARY KEY,
                allowed_scopes TEXT NOT NULL,
                frontchannel_scopes TEXT NOT NULL,
                redirect_hosts TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                subject TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS pars (
                request_uri TEXT PRIMARY KEY,
                client_id TEXT NOT NULL,
                redirect_uri TEXT NOT NULL,
                scope TEXT NOT NULL,
                state TEXT NOT NULL,
                code_challenge TEXT NOT NULL,
                created REAL NOT NULL,
                consumed INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS codes (
                code TEXT PRIMARY KEY,
                client_id TEXT NOT NULL,
                subject TEXT NOT NULL,
                redirect_uri TEXT NOT NULL,
                granted_scope TEXT NOT NULL,
                code_challenge TEXT NOT NULL,
                created REAL NOT NULL,
                used INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        conn.execute(
            "INSERT OR REPLACE INTO clients VALUES (?,?,?,?)",
            (
                "passgate-console",
                "openid profile admin:read",
                "openid profile",
                "console.passgate.htl",
            ),
        )
        conn.execute(
            "INSERT OR REPLACE INTO users VALUES (?,?,?)",
            ("admin", admin_password, "admin"),
        )


def get_client(client_id: str):
    with _connect() as conn:
        return conn.execute(
            "SELECT * FROM clients WHERE client_id=?", (client_id,)
        ).fetchone()


def get_user(username: str):
    with _connect() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE username=?", (username,)
        ).fetchone()


def create_par(request_uri, client_id, redirect_uri, scope, state, challenge) -> None:
    with _connect() as conn:
        conn.execute(
            "INSERT INTO pars VALUES (?,?,?,?,?,?,?,0)",
            (request_uri, client_id, redirect_uri, scope, state, challenge, time.time()),
        )


def get_par(request_uri: str):
    with _connect() as conn:
        return conn.execute(
            "SELECT * FROM pars WHERE request_uri=?", (request_uri,)
        ).fetchone()


def consume_par(request_uri: str) -> None:
    with _connect() as conn:
        conn.execute(
            "UPDATE pars SET consumed=1 WHERE request_uri=?", (request_uri,)
        )


def list_pending_pars() -> list[str]:
    cutoff = time.time() - 90
    with _connect() as conn:
        rows = conn.execute(
            "SELECT request_uri FROM pars WHERE consumed=0 AND created>=? "
            "ORDER BY created ASC",
            (cutoff,),
        ).fetchall()
    return [r["request_uri"] for r in rows]


def create_code(code, client_id, subject, redirect_uri, granted_scope, challenge) -> None:
    with _connect() as conn:
        conn.execute(
            "INSERT INTO codes VALUES (?,?,?,?,?,?,?,0)",
            (code, client_id, subject, redirect_uri, granted_scope, challenge, time.time()),
        )


def get_code(code: str):
    with _connect() as conn:
        return conn.execute(
            "SELECT * FROM codes WHERE code=?", (code,)
        ).fetchone()


def mark_code_used(code: str) -> None:
    with _connect() as conn:
        conn.execute("UPDATE codes SET used=1 WHERE code=?", (code,))
