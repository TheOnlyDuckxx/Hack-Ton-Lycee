"""URL helpers for the authorization server."""
from __future__ import annotations

from urllib.parse import urlencode, urlsplit


def _browser_host(uri: str) -> str | None:
    """Resolve the authority a user agent would navigate to.

    User agents fold backslashes to forward slashes for the special schemes
    (http/https/ws/wss/ftp) before splitting the authority, so we mirror that
    normalisation when deciding whether a redirect target is in policy.
    """
    normalized = uri.replace("\\", "/")
    try:
        return urlsplit(normalized).hostname
    except ValueError:
        return None


def validate_redirect_uri(uri: str, allowed_hosts: list[str]) -> bool:
    host = _browser_host(uri)
    if not host:
        return False
    allowed = {h.strip().lower() for h in allowed_hosts if h.strip()}
    return host.lower() in allowed


def build_redirect(uri: str, params: dict[str, str]) -> str:
    parts = urlsplit(uri)
    host = parts.hostname or ""
    netloc = host
    if parts.port:
        netloc = f"{host}:{parts.port}"
    path = parts.path or "/"
    base = f"{parts.scheme}://{netloc}{path}"
    if parts.query:
        base += "?" + parts.query
        sep = "&"
    else:
        sep = "?"
    return f"{base}{sep}{urlencode(params)}"
