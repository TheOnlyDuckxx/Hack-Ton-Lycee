"""PassGate: an in-house OAuth2 authorization server and resource API."""
from __future__ import annotations

import base64
import hashlib
import os
import pathlib
import secrets
import time

import jwt
from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    session,
)

import db
from urltools import build_redirect, validate_redirect_uri

BASE = pathlib.Path(__file__).resolve().parent

ISSUER = "https://passgate.htl"
SCOPES_SUPPORTED = ["openid", "profile", "admin:read"]
JWT_ALG = "HS256"
TOKEN_TTL = 300

CONSUMED_CHALLENGES: set[str] = set()
LIVE_GRANTS: dict[str, set[str]] = {}

_DECOY_JWK = {
    "kty": "RSA",
    "use": "sig",
    "alg": "RS256",
    "kid": "passgate-2025",
    "n": (
        "0vx7agoebGcQSuuPiLJXZptN9nndrQmbXEps2aiAFbWhM78LhWx4cbbfAAtVT86z"
        "wu1RK7aPFFxuhDR1L6tSoc_BJECPebWKRXjBZCiFV4n3oknjhMstn64tZ_2W-5Jso"
        "mdn-GdocoH8s4fH7-jE2m1wWyF0JCZ4nHqZ2z8hp0"
    ),
    "e": "AQAB",
}


def _load_flag() -> str:
    try:
        return pathlib.Path("/srv/flag.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return "HTL{dev_default_redirace}"


def _parse_scope(raw: str) -> set[str]:
    return {s for s in (raw or "").split() if s}


def _issue_token(subject: str, scopes: set[str]) -> str:
    now = int(time.time())
    claims = {
        "iss": ISSUER,
        "sub": subject,
        "scope": " ".join(sorted(scopes)),
        "client_id": "passgate-console",
        "iat": now,
        "exp": now + TOKEN_TTL,
        "jti": secrets.token_hex(8),
    }
    return jwt.encode(claims, SECRET, algorithm=JWT_ALG)


def _pkce_verifies(challenge: str, verifier: str) -> bool:
    if not verifier:
        return False
    digest = hashlib.sha256(verifier.encode()).digest()
    computed = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
    return secrets.compare_digest(computed, challenge)


FLAG = _load_flag()
SECRET = secrets.token_hex(32)
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "passgate-admin")

db.init_db(ADMIN_PASSWORD)

app = Flask(__name__)
app.secret_key = os.urandom(32)


@app.get("/")
def index():
    return render_template("index.html", issuer=ISSUER)


@app.get("/healthz")
def healthz():
    return "ok", 200


@app.get("/params")
def params():
    return jsonify(
        issuer=ISSUER,
        pushed_authorization_request_endpoint="/par",
        authorization_endpoint="/authorize",
        token_endpoint="/token",
        resource_endpoint="/resource",
        jwks_uri="/jwks",
        client_id="passgate-console",
        scopes_supported=SCOPES_SUPPORTED,
        registered_redirect_hosts=["console.passgate.htl"],
        token_endpoint_auth_signing_alg_values_supported=["RS256", "HS256"],
        callback_inspector={
            "sink": "http://collector.passgate.htl:8004/cb",
            "read": "/inspect?state=<state>",
            "note": "integration sandbox for non-production redirect hosts",
        },
    )


@app.get("/jwks")
def jwks():
    return jsonify(keys=[_DECOY_JWK])


@app.post("/login")
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    user = db.get_user(username)
    if user is None or not secrets.compare_digest(user["password"], password):
        return jsonify(error="invalid_credentials"), 401
    session.clear()
    session["subject"] = user["subject"]
    return jsonify(ok=True, subject=user["subject"])


@app.post("/par")
def pushed_authorization_request():
    client_id = request.form.get("client_id", "")
    client = db.get_client(client_id)
    if client is None:
        return jsonify(error="invalid_client"), 400

    redirect_uri = request.form.get("redirect_uri", "")
    allowed_hosts = client["redirect_hosts"].split()
    if not validate_redirect_uri(redirect_uri, allowed_hosts):
        return jsonify(error="invalid_redirect_uri"), 400

    scope = request.form.get("scope", "")
    state = request.form.get("state", "")
    challenge = request.form.get("code_challenge", "")

    request_uri = "urn:passgate:par:" + secrets.token_urlsafe(16)
    db.create_par(request_uri, client_id, redirect_uri, scope, state, challenge)
    return jsonify(request_uri=request_uri, expires_in=90)


@app.get("/pending")
def pending():
    if "subject" not in session:
        return jsonify(error="login_required"), 401
    return jsonify(pending=db.list_pending_pars())


@app.get("/authorize")
def authorize():
    if "subject" not in session:
        return jsonify(error="login_required"), 401

    request_uri = request.args.get("request_uri", "")
    par = db.get_par(request_uri)
    if par is None or par["consumed"]:
        return jsonify(error="invalid_request"), 400

    client = db.get_client(par["client_id"])
    frontchannel = _parse_scope(client["frontchannel_scopes"])
    requested = _parse_scope(par["scope"])
    granted = (requested & frontchannel) if requested else set(frontchannel)

    code = secrets.token_urlsafe(24)
    db.create_code(
        code,
        par["client_id"],
        session["subject"],
        par["redirect_uri"],
        " ".join(sorted(granted)),
        par["code_challenge"],
    )
    db.consume_par(request_uri)

    location = build_redirect(
        par["redirect_uri"], {"code": code, "state": par["state"]}
    )
    return redirect(location, code=302)


@app.post("/token")
def token():
    if request.form.get("grant_type") != "authorization_code":
        return jsonify(error="unsupported_grant_type"), 400

    code = request.form.get("code", "")
    row = db.get_code(code)
    if row is None:
        return jsonify(error="invalid_grant"), 400
    if row["used"]:
        return jsonify(error="invalid_grant", error_description="code already redeemed"), 400

    requested = _parse_scope(request.form.get("scope", ""))
    client = db.get_client(row["client_id"])
    allowed = _parse_scope(client["allowed_scopes"])
    granted = _parse_scope(row["granted_scope"])

    if row["code_challenge"]:
        verifier = request.form.get("code_verifier", "")
        if row["code_challenge"] in CONSUMED_CHALLENGES:
            return jsonify(error="invalid_grant", error_description="challenge replay"), 400
        if not _pkce_verifies(row["code_challenge"], verifier):
            return jsonify(error="invalid_grant", error_description="pkce_mismatch"), 400
        CONSUMED_CHALLENGES.add(row["code_challenge"])

    if code in LIVE_GRANTS:
        base = LIVE_GRANTS[code]
        effective = (requested or base) & allowed
    else:
        LIVE_GRANTS[code] = set(granted)
        effective = (requested & granted) if requested else set(granted)

    access_token = _issue_token(row["subject"], effective)
    db.mark_code_used(code)

    return jsonify(
        access_token=access_token,
        token_type="Bearer",
        scope=" ".join(sorted(effective)),
        expires_in=TOKEN_TTL,
    )


@app.get("/resource")
def resource():
    header = request.headers.get("Authorization", "")
    if not header.lower().startswith("bearer "):
        return jsonify(error="invalid_token"), 401
    raw = header.split(" ", 1)[1].strip()
    try:
        claims = jwt.decode(raw, SECRET, algorithms=[JWT_ALG], issuer=ISSUER)
    except jwt.PyJWTError:
        return jsonify(error="invalid_token"), 401

    scopes = _parse_scope(claims.get("scope", ""))
    if "admin:read" not in scopes:
        return jsonify(error="insufficient_scope", required="admin:read"), 403
    return jsonify(subject=claims.get("sub"), flag=FLAG)


CAPTURES: list[dict] = []


@app.route("/cb")
def callback_inspector():
    host = request.host.split(":")[0].lower()
    client = db.get_client("passgate-console")
    production = {h.strip().lower() for h in client["redirect_hosts"].split()}
    if host in production:
        return "callback received", 200
    entry = dict(request.args)
    entry["_received"] = time.time()
    CAPTURES.append(entry)
    return "ok", 200


@app.get("/inspect")
def inspect():
    state = request.args.get("state", "")
    hits = [c for c in CAPTURES if c.get("state") == state]
    return jsonify(captures=hits)
