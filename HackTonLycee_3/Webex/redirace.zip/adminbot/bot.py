"""Internal console operator: approves pending authorization requests."""
from __future__ import annotations

import os
import time

import requests

BASE = os.environ.get("AUTH_BASE", "http://console.passgate.htl:8004")
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "passgate-admin")
INTERVAL = float(os.environ.get("APPROVE_INTERVAL", "1.0"))


def make_session() -> requests.Session:
    sess = requests.Session()
    while True:
        try:
            resp = sess.post(
                f"{BASE}/login",
                data={"username": ADMIN_USER, "password": ADMIN_PASSWORD},
                timeout=5,
            )
            if resp.status_code == 200:
                print("[bot] authenticated", flush=True)
                return sess
            print(f"[bot] login status {resp.status_code}", flush=True)
        except requests.RequestException as exc:
            print(f"[bot] login error: {exc}", flush=True)
        time.sleep(2)


def main() -> None:
    sess = make_session()
    while True:
        try:
            pending = sess.get(f"{BASE}/pending", timeout=5)
            if pending.status_code == 401:
                sess = make_session()
                continue
            handles = pending.json().get("pending", [])
            for request_uri in handles:
                try:
                    sess.get(
                        f"{BASE}/authorize",
                        params={"request_uri": request_uri},
                        timeout=5,
                        allow_redirects=True,
                    )
                except requests.RequestException as exc:
                    print(f"[bot] approve error: {exc}", flush=True)
        except requests.RequestException as exc:
            print(f"[bot] loop error: {exc}", flush=True)
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
