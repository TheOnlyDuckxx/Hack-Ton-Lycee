pollstar
========

A single Linux x86-64 executable, built from Rust and stripped.

    $ ./pollstar 'YOUR_GUESS_HERE'
    Nope.

It also reads a candidate from stdin if no argument is given:

    $ echo -n 'YOUR_GUESS_HERE' | ./pollstar

Exactly one input makes it print `Correct.`. That input is the flag.
