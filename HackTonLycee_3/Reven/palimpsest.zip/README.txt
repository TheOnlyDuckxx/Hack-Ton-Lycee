palimpsest
==========

A single statically-linked Linux x86-64 executable.

    $ ./palimpsest 'YOUR_GUESS_HERE'
    Nope.

It also reads a candidate from stdin if no argument is given:

    $ echo -n 'YOUR_GUESS_HERE' | ./palimpsest

Find the one input it calls Correct. That input is the flag.
