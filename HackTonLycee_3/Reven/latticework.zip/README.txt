latticework
===========

A Lattice iCE40 FPGA bitstream and the headless oracle that runs it.

Files
-----
  latticework.bin   packed iCE40 (HX8K / ct256) bitstream -- the design to reverse
  oracle            headless gate-level emulator of that design (ELF x86-64)

The design is a bit-serial flag validator. There is no CPU and no .text: the
logic lives entirely in the fabric. It clocks a candidate in one bit at a time
and raises a single `valid` signal for exactly one input stream. That input is
the flag.

The oracle
----------
The oracle emulates the author's design and exposes its raw clk / rst / din /
valid interface over TCP. Connect and talk to it one line at a time:

    reset            reset the device (pulse rst)              -> ok
    in <0|1>         drive the serial input wire               -> ok
    step [n]         advance n clock edges (default 1)         -> valid <b>
    valid            read the current valid output             -> valid <b>
    quit             close                                     -> bye

Example:

    $ nc <host> 5001
    reset
    ok
    in 1
    ok
    step
    valid 0
    ...

Recovering the gates
--------------------
The bitstream is a stock iCE40 pack; Project IceStorm reverses it:

    iceunpack latticework.bin > latticework.asc
    icebox_vlog latticework.asc > netlist.v        # or: yosys read_ilang / show

Reconstruct the clocked protocol from the netlist, pull the constants out of
the initialised block RAM, and work out the one input stream that drives
`valid` high. That stream, read back as bytes, is the flag.
