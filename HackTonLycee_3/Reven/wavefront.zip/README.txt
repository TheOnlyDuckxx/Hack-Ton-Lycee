wavefront
=========

A headless Vulkan compute-shader crackme. It loads a SPIR-V kernel and runs it
on any Vulkan 1.1 device; a software device (Mesa lavapipe / llvmpipe) is fine,
no GPU required.

Files
-----
  wavefront        host program (ELF x86-64)
  wavefront.spv    stripped SPIR-V compute kernel (the thing to reverse)
  perm.bin         little-endian u32 count + values  (lane load permutation)
  sigma.bin        little-endian u32 count + values  (inter-round shuffle)
  texture.bin      60-byte R8_UNORM texture sampled by the kernel

Run
---
Run from this directory so the data files are found.

    $ ./wavefront 'YOUR_GUESS_HERE'
    Nope.

It also reads a candidate from stdin if no argument is given:

    $ printf 'YOUR_GUESS_HERE' | ./wavefront

To force the software Vulkan device (lavapipe):

    $ VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.x86_64.json \
        ./wavefront 'YOUR_GUESS_HERE'

Find the one input it calls Correct. That input is the flag.
