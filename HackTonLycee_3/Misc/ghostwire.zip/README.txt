GHOSTWIRE
=========

An EDR agent flagged an outbound QUIC (HTTP/3-looking) session from an
internal workstation to an unfamiliar endpoint and triggered a response.
By the time the box was isolated the operator's tooling had already wiped
the on-disk TLS key log, so Wireshark cannot decrypt the capture on its
own. The responders pulled two things before shutdown:

  c2_session.pcap   - full packet capture of the suspicious QUIC session
                      (QUIC v1, 1-RTT / short-header packets).

  host_memory.raw   - a raw physical-memory image of the host, taken while
                      the agent process was still resident.

Recover whatever was exfiltrated.


Analyst note (from a prior triage of this malware family)
---------------------------------------------------------

The agent is statically linked against a BoringSSL-derived TLS stack. Its
per-connection key material is kept in a small heap record. During a
previous sample we recovered the record layout; the live object is tagged
with an 8-byte signature so you can find it in a dump:

    signature : 8 bytes   ASCII "KSCHED" followed by 0x01 0x00
    version   : u32 (big-endian)
    suite     : u16 (big-endian)         TLS cipher-suite id
    cid_len   : u8                       active connection-id length
    _pad      : u8
    cid       : 20-byte buffer           (cid_len bytes used)
    <... keying material for both directions, then the per-direction
         nonces, laid out back to back ...>

Several of these records may survive in the heap (re-keys, closed or
stale connections). Only the one whose connection id matches the capture
belongs to the session you care about.

The transport labels this family uses for key derivation are the standard
QUIC v1 ones. Nothing in the dump is pre-derived for you beyond what the
layout above describes - the packet-protection keys still have to be
expanded, and the application payload is framed by the malware's own C2
protocol on top of the QUIC stream.

That C2 framing, from the same prior sample: the exfiltrated bytes are a run
of length-prefixed chunks - a 2-byte big-endian length followed by that many
payload bytes - and the whole concatenated run is masked with an XOR keystream
whose p-th byte combines the connection id (repeating) with a position-dependent
term. The small constants of that term were not recovered from the prior sample.
