SLACKTIDE
=========

disk.img is a raw image pulled from a workstation during an incident
response. The analyst swears the secret is "still on there somewhere",
but a routine cleanup pass ran before the image was captured, and parts
of whatever was hidden did not survive.

Recover the secret. Format: HTL{...}

Notes:
  - This is a carving exercise. The image is NOT guaranteed to mount
    cleanly; work from the raw bytes.
  - Everything you need is inside disk.img.
  - The bytes you carve are the symbols of one Reed-Solomon codeword: 55
    one-byte symbols, indices 0-54, of which 24 are parity (a standard
    reedsolo RSCodec(24) over GF(2^8)). Place each symbol you recover at its
    index, and treat every index you cannot recover as an erasure.
