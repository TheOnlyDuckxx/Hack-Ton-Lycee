# Sidewinder

A payments platform runs its ledger behind a service mesh. Workloads
authenticate to each other with mTLS, and the ledger sidecar enforces an
`AuthorizationPolicy` that is supposed to admit exactly two callers:

- the **checkout writer** — service account `checkout.v2` in namespace `pay` —
  may `POST /ledger/append`;
- the **reconciler** — service account `reconciler` in namespace
  `ledger-ops` — may `GET /ledger/reconcile`.

Everyone else must be rejected at the sidecar.

A red-team report says an impostor workload is reaching `/ledger/append`
anyway, even though it is not `checkout.v2`. Your job: re-scope the policy so
the impostor identities get `403`, while **both** legitimate callers keep
getting `200` on their authorized verb and path. A fix that locks out either
legitimate caller does not count.

## How the mesh matches identity

Each caller presents a workload certificate whose SPIFFE URI SAN is its
identity, e.g. `spiffe://cluster.local/ns/pay/sa/checkout.v2`. The sidecar
strips the `spiffe://` scheme and matches the remainder against each
`principals` entry in the active policy.

This mesh build compiles every `principals`, `hosts`, `paths` and header value
entry into an **RE2 matcher** and requires a full-string match. `*` expands to
`.*`. Other characters are used verbatim.

`to.operation.hosts` are matched against the request authority
case-insensitively. `when` header conditions match if the request header equals
any listed value.

## The policy you edit

`manifests/authz.yaml` is the live `AuthorizationPolicy`. `manifests/` also
ships `peerauth.yaml` and `ledger-service.yaml` as read-only context — only
`authz.yaml` changes enforcement.

## Fetch, edit, submit

Everything goes through the grader. It evaluates the policy you submit against
the identity matrix in-request, with the same matcher the sidecar enforces, and
returns the verdict (and the flag, on success) to you. Each submission is scored
on its own — nothing is stored between requests.

```sh
# the as-found baseline policy, as an editing template
curl -s http://GRADER_HOST:GRADER_PORT/policy -o authz.yaml

# edit authz.yaml, then submit it for scoring
curl -s -X POST --data-binary @authz.yaml http://GRADER_HOST:GRADER_PORT/apply
```

`/grade` accepts the same POSTed policy if you prefer; a bare `GET /grade` with
no policy submits nothing and never returns the flag.

The flag is returned only when every impostor identity is denied **and** both
legitimate callers are still served.
