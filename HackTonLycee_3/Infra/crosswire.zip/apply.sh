#!/bin/sh
# Submit the edited trust policy to the grader for scoring.
#
# The grader evaluates the policy you send, in-request, and returns the verdict
# (and the flag, if it both rejects the incident context and keeps the real
# deploy working). Nothing is stored server-side; each submission is scored on
# its own.
#
#   ./apply.sh http://GRADER_HOST:8052
set -e

POLICY_FILE="${POLICY_FILE:-trust-policy.json}"
GRADER="${1:-http://localhost:8052}"

curl -sf -X POST "${GRADER%/}/grade" \
  -H 'content-type: application/json' \
  --data "$(printf '{"trust_policy": %s}' "$(cat "$POLICY_FILE")")"
echo
