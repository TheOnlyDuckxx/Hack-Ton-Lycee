# Crosswire

CI for `acme-corp/urlmin-deploy` ships to AWS with no long-lived keys: the
`deploy` workflow requests a GitHub Actions OIDC token and exchanges it, via the
account's OIDC provider, for the `github-deploy-role` IAM role
(`sts:AssumeRoleWithWebIdentity`). The role can write to the production
artifacts bucket.

During the last incident response, a captured OIDC token (`captured-token.jwt`)
showed a workflow run that was **not** the production deploy assuming
`github-deploy-role`. The role's trust policy (`trust-policy.json`) is the thing
that decides who may exchange a token for the role. It is currently too loose.

Harden the trust policy so the captured context can no longer assume the role,
**without** breaking the real deploy in `deploy.yml`. Then apply it and ask the
grader to check.

## Layout

- `trust-policy.json` - the deploy role's `AssumeRolePolicyDocument`. Edit this.
- `deploy.yml` - the one workflow that is supposed to reach the role.
- `captured-token.jwt` - an OIDC token observed assuming the role during the
  incident.

## Workflow

```sh
export GRADER=http://HOST:8052          # this instance's grader
# ... edit trust-policy.json ...
sh apply.sh "$GRADER"                    # submit the policy; prints the verdict
```

`apply.sh` just POSTs your policy to the grader; the equivalent raw call is:

```sh
curl -s -X POST "$GRADER/grade" -H 'content-type: application/json' \
  --data "$(printf '{"trust_policy": %s}' "$(cat trust-policy.json)")"
```

The grader mints the pipeline's real deploy token and the incident token and
evaluates **the policy you submit**, in-request, against each. The flag is
returned only when that policy is both **secure** (the incident context is
rejected) and **functional** (the real deploy still assumes the role and keeps
its deploy permission). Each submission is scored on its own — nothing is stored
between requests.
