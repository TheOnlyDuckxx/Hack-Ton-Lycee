const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const mysql = require("mysql");
require("dotenv").config();

const secretKey = "competition_secret_key";

// Create MySQL connection pool with simplified credentials
const pool = mysql.createConnection({
  host: process.env.DB_HOST || 'db',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'pass',
  database: process.env.DB_NAME || 'competition_db',
  port: 3306,
});

const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    pool.query(
      "SELECT * FROM users WHERE username = ?",
      [username],
      async (error, results) => {
        if (error) {
          console.error("Error during login:", error);
          return res.status(500).json({ error: "Failed to login" });
        }

        if (results.length === 0) {
          return res
            .status(401)
            .render("login", { error: "Incorrect Information" });
        }

        const user = results[0];
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
          return res
            .status(401)
            .render("login", { error: "Incorrect Information" });
        }

        const token = jwt.sign(
          { userId: user.id, username: user.username, role: user.role },
          secretKey
        );
        res.cookie("token", token);
        return res.redirect("/");
      }
    );
  } catch (error) {
    console.error("Error during login:", error);
    return res.status(500).json({ error: "Failed to login" });
  }
};

const register = async (req, res) => {
  const { username, email, password, cpassword } = req.body;

  try {
    pool.query(
      "SELECT * FROM users WHERE username = ?",
      [username],
      async (error, results) => {
        if (error) {
          console.error("Error during registration:", error);
          return res.status(500).json({ error: "Failed to register" });
        }

        if (results.length > 0) {
          return res
            .status(401)
            .render("register", { error: "Username already exists" });
        }
        if (password !== cpassword) {
          return res
            .status(401)
            .render("register", { error: "Password mismatch" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        pool.query(
          "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)",
          [username, hashedPassword, email, "user"],
          (error) => {
            if (error) {
              console.error("Error during registration:", error);
              return res.status(500).json({ error: "Failed to register" });
            }
            return res.redirect("/login");
          }
        );
      }
    );
  } catch (error) {
    console.error("Error during registration:", error);
    return res.status(500).json({ error: "Failed to register" });
  }
};

module.exports = {
  login,
  register,
};
