CREATE DATABASE IF NOT EXISTS competition_db;
USE competition_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    role VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    department VARCHAR(255),
    description TEXT,
    severity VARCHAR(255),
    type VARCHAR(20)
);

-- Insert users (username == password)
INSERT INTO users (username, password, email, role) VALUES
('admin', 'HACKTONLYUCEE{THIS_IS_NOT_THE_FLAG}', 'administrator@admin.com', 'admin');

-- Insert tickets
INSERT INTO support_tickets (title, department, description, severity, type) VALUES
('Issue with Email Configuration', 'IT', 'Users are unable to send emails.', 'high', 'unresolved'),
('Network Connectivity Problem', 'Network', 'Several users are reporting intermittent internet connectivity.', 'medium', 'unresolved'),
('Printer Not Printing', 'IT', 'Printer in room 301 is not printing documents.', 'low', 'resolved'),
('Software Installation Error', 'IT', 'Unable to install software on user workstation.', 'medium', 'unresolved'),
('Password Reset Request', 'IT', 'User forgot their password and needs it reset.', 'low', 'resolved');
