
import json
import base64
import hashlib
import hmac
import os

SECRET = os.urandom(32)

def get_signature(payload):
    payload = base64.urlsafe_b64decode(payload + '==').decode()
    print(json.loads(payload).get("username"))
    signature = hmac.new(SECRET, json.loads(payload).get("username").encode(), hashlib.sha256).digest()
    signature = base64.urlsafe_b64encode(signature).decode().rstrip('=')
    return signature
